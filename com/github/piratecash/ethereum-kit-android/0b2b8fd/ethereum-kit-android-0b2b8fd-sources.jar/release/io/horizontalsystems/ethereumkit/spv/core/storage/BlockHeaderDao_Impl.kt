package io.horizontalsystems.ethereumkit.spv.core.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.api.storage.RoomTypeConverters
import io.horizontalsystems.ethereumkit.spv.models.BlockHeader
import java.math.BigInteger
import javax.`annotation`.processing.Generated
import kotlin.ByteArray
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class BlockHeaderDao_Impl(
  __db: RoomDatabase,
) : BlockHeaderDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfBlockHeader: EntityInsertAdapter<BlockHeader>

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()
  init {
    this.__db = __db
    this.__insertAdapterOfBlockHeader = object : EntityInsertAdapter<BlockHeader>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `BlockHeader` (`height`,`hashHex`,`totalDifficulty`,`parentHash`,`unclesHash`,`coinbase`,`stateRoot`,`transactionsRoot`,`receiptsRoot`,`logsBloom`,`difficulty`,`gasLimit`,`gasUsed`,`timestamp`,`extraData`,`mixHash`,`nonce`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: BlockHeader) {
        statement.bindLong(1, entity.height)
        statement.bindBlob(2, entity.hashHex)
        val _tmp: String? = __roomTypeConverters.bigIntegerToString(entity.totalDifficulty)
        if (_tmp == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmp)
        }
        statement.bindBlob(4, entity.parentHash)
        statement.bindBlob(5, entity.unclesHash)
        statement.bindBlob(6, entity.coinbase)
        statement.bindBlob(7, entity.stateRoot)
        statement.bindBlob(8, entity.transactionsRoot)
        statement.bindBlob(9, entity.receiptsRoot)
        statement.bindBlob(10, entity.logsBloom)
        statement.bindBlob(11, entity.difficulty)
        statement.bindBlob(12, entity.gasLimit)
        statement.bindLong(13, entity.gasUsed)
        statement.bindLong(14, entity.timestamp)
        statement.bindBlob(15, entity.extraData)
        statement.bindBlob(16, entity.mixHash)
        statement.bindBlob(17, entity.nonce)
      }
    }
  }

  public override fun insert(blockHeader: BlockHeader): Unit = performBlocking(__db, false, true) {
      _connection ->
    __insertAdapterOfBlockHeader.insert(_connection, blockHeader)
  }

  public override fun insertAll(blockHeaders: List<BlockHeader>): Unit = performBlocking(__db,
      false, true) { _connection ->
    __insertAdapterOfBlockHeader.insert(_connection, blockHeaders)
  }

  public override fun getByHashHex(hashHex: ByteArray): BlockHeader {
    val _sql: String = "SELECT * FROM BlockHeader WHERE hashHex=?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindBlob(_argIndex, hashHex)
        val _columnIndexOfHeight: Int = getColumnIndexOrThrow(_stmt, "height")
        val _columnIndexOfHashHex: Int = getColumnIndexOrThrow(_stmt, "hashHex")
        val _columnIndexOfTotalDifficulty: Int = getColumnIndexOrThrow(_stmt, "totalDifficulty")
        val _columnIndexOfParentHash: Int = getColumnIndexOrThrow(_stmt, "parentHash")
        val _columnIndexOfUnclesHash: Int = getColumnIndexOrThrow(_stmt, "unclesHash")
        val _columnIndexOfCoinbase: Int = getColumnIndexOrThrow(_stmt, "coinbase")
        val _columnIndexOfStateRoot: Int = getColumnIndexOrThrow(_stmt, "stateRoot")
        val _columnIndexOfTransactionsRoot: Int = getColumnIndexOrThrow(_stmt, "transactionsRoot")
        val _columnIndexOfReceiptsRoot: Int = getColumnIndexOrThrow(_stmt, "receiptsRoot")
        val _columnIndexOfLogsBloom: Int = getColumnIndexOrThrow(_stmt, "logsBloom")
        val _columnIndexOfDifficulty: Int = getColumnIndexOrThrow(_stmt, "difficulty")
        val _columnIndexOfGasLimit: Int = getColumnIndexOrThrow(_stmt, "gasLimit")
        val _columnIndexOfGasUsed: Int = getColumnIndexOrThrow(_stmt, "gasUsed")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfExtraData: Int = getColumnIndexOrThrow(_stmt, "extraData")
        val _columnIndexOfMixHash: Int = getColumnIndexOrThrow(_stmt, "mixHash")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _result: BlockHeader
        if (_stmt.step()) {
          val _tmpHeight: Long
          _tmpHeight = _stmt.getLong(_columnIndexOfHeight)
          val _tmpHashHex: ByteArray
          _tmpHashHex = _stmt.getBlob(_columnIndexOfHashHex)
          val _tmpTotalDifficulty: BigInteger
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfTotalDifficulty)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfTotalDifficulty)
          }
          val _tmp_1: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTotalDifficulty = _tmp_1
          }
          val _tmpParentHash: ByteArray
          _tmpParentHash = _stmt.getBlob(_columnIndexOfParentHash)
          val _tmpUnclesHash: ByteArray
          _tmpUnclesHash = _stmt.getBlob(_columnIndexOfUnclesHash)
          val _tmpCoinbase: ByteArray
          _tmpCoinbase = _stmt.getBlob(_columnIndexOfCoinbase)
          val _tmpStateRoot: ByteArray
          _tmpStateRoot = _stmt.getBlob(_columnIndexOfStateRoot)
          val _tmpTransactionsRoot: ByteArray
          _tmpTransactionsRoot = _stmt.getBlob(_columnIndexOfTransactionsRoot)
          val _tmpReceiptsRoot: ByteArray
          _tmpReceiptsRoot = _stmt.getBlob(_columnIndexOfReceiptsRoot)
          val _tmpLogsBloom: ByteArray
          _tmpLogsBloom = _stmt.getBlob(_columnIndexOfLogsBloom)
          val _tmpDifficulty: ByteArray
          _tmpDifficulty = _stmt.getBlob(_columnIndexOfDifficulty)
          val _tmpGasLimit: ByteArray
          _tmpGasLimit = _stmt.getBlob(_columnIndexOfGasLimit)
          val _tmpGasUsed: Long
          _tmpGasUsed = _stmt.getLong(_columnIndexOfGasUsed)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpExtraData: ByteArray
          _tmpExtraData = _stmt.getBlob(_columnIndexOfExtraData)
          val _tmpMixHash: ByteArray
          _tmpMixHash = _stmt.getBlob(_columnIndexOfMixHash)
          val _tmpNonce: ByteArray
          _tmpNonce = _stmt.getBlob(_columnIndexOfNonce)
          _result =
              BlockHeader(_tmpHashHex,_tmpTotalDifficulty,_tmpParentHash,_tmpUnclesHash,_tmpCoinbase,_tmpStateRoot,_tmpTransactionsRoot,_tmpReceiptsRoot,_tmpLogsBloom,_tmpDifficulty,_tmpHeight,_tmpGasLimit,_tmpGasUsed,_tmpTimestamp,_tmpExtraData,_tmpMixHash,_tmpNonce)
        } else {
          error("The query result was empty, but expected a single row to return a NON-NULL object of type <io.horizontalsystems.ethereumkit.spv.models.BlockHeader>.")
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getAll(): List<BlockHeader> {
    val _sql: String = "SELECT * FROM BlockHeader ORDER BY height DESC"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHeight: Int = getColumnIndexOrThrow(_stmt, "height")
        val _columnIndexOfHashHex: Int = getColumnIndexOrThrow(_stmt, "hashHex")
        val _columnIndexOfTotalDifficulty: Int = getColumnIndexOrThrow(_stmt, "totalDifficulty")
        val _columnIndexOfParentHash: Int = getColumnIndexOrThrow(_stmt, "parentHash")
        val _columnIndexOfUnclesHash: Int = getColumnIndexOrThrow(_stmt, "unclesHash")
        val _columnIndexOfCoinbase: Int = getColumnIndexOrThrow(_stmt, "coinbase")
        val _columnIndexOfStateRoot: Int = getColumnIndexOrThrow(_stmt, "stateRoot")
        val _columnIndexOfTransactionsRoot: Int = getColumnIndexOrThrow(_stmt, "transactionsRoot")
        val _columnIndexOfReceiptsRoot: Int = getColumnIndexOrThrow(_stmt, "receiptsRoot")
        val _columnIndexOfLogsBloom: Int = getColumnIndexOrThrow(_stmt, "logsBloom")
        val _columnIndexOfDifficulty: Int = getColumnIndexOrThrow(_stmt, "difficulty")
        val _columnIndexOfGasLimit: Int = getColumnIndexOrThrow(_stmt, "gasLimit")
        val _columnIndexOfGasUsed: Int = getColumnIndexOrThrow(_stmt, "gasUsed")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfExtraData: Int = getColumnIndexOrThrow(_stmt, "extraData")
        val _columnIndexOfMixHash: Int = getColumnIndexOrThrow(_stmt, "mixHash")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _result: MutableList<BlockHeader> = mutableListOf()
        while (_stmt.step()) {
          val _item: BlockHeader
          val _tmpHeight: Long
          _tmpHeight = _stmt.getLong(_columnIndexOfHeight)
          val _tmpHashHex: ByteArray
          _tmpHashHex = _stmt.getBlob(_columnIndexOfHashHex)
          val _tmpTotalDifficulty: BigInteger
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfTotalDifficulty)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfTotalDifficulty)
          }
          val _tmp_1: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTotalDifficulty = _tmp_1
          }
          val _tmpParentHash: ByteArray
          _tmpParentHash = _stmt.getBlob(_columnIndexOfParentHash)
          val _tmpUnclesHash: ByteArray
          _tmpUnclesHash = _stmt.getBlob(_columnIndexOfUnclesHash)
          val _tmpCoinbase: ByteArray
          _tmpCoinbase = _stmt.getBlob(_columnIndexOfCoinbase)
          val _tmpStateRoot: ByteArray
          _tmpStateRoot = _stmt.getBlob(_columnIndexOfStateRoot)
          val _tmpTransactionsRoot: ByteArray
          _tmpTransactionsRoot = _stmt.getBlob(_columnIndexOfTransactionsRoot)
          val _tmpReceiptsRoot: ByteArray
          _tmpReceiptsRoot = _stmt.getBlob(_columnIndexOfReceiptsRoot)
          val _tmpLogsBloom: ByteArray
          _tmpLogsBloom = _stmt.getBlob(_columnIndexOfLogsBloom)
          val _tmpDifficulty: ByteArray
          _tmpDifficulty = _stmt.getBlob(_columnIndexOfDifficulty)
          val _tmpGasLimit: ByteArray
          _tmpGasLimit = _stmt.getBlob(_columnIndexOfGasLimit)
          val _tmpGasUsed: Long
          _tmpGasUsed = _stmt.getLong(_columnIndexOfGasUsed)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpExtraData: ByteArray
          _tmpExtraData = _stmt.getBlob(_columnIndexOfExtraData)
          val _tmpMixHash: ByteArray
          _tmpMixHash = _stmt.getBlob(_columnIndexOfMixHash)
          val _tmpNonce: ByteArray
          _tmpNonce = _stmt.getBlob(_columnIndexOfNonce)
          _item =
              BlockHeader(_tmpHashHex,_tmpTotalDifficulty,_tmpParentHash,_tmpUnclesHash,_tmpCoinbase,_tmpStateRoot,_tmpTransactionsRoot,_tmpReceiptsRoot,_tmpLogsBloom,_tmpDifficulty,_tmpHeight,_tmpGasLimit,_tmpGasUsed,_tmpTimestamp,_tmpExtraData,_tmpMixHash,_tmpNonce)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getByBlockHeightRange(startHeight: Long, endHeight: Long): List<BlockHeader> {
    val _sql: String = "SELECT * FROM BlockHeader WHERE height BETWEEN ? AND ? ORDER BY height ASC"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, startHeight)
        _argIndex = 2
        _stmt.bindLong(_argIndex, endHeight)
        val _columnIndexOfHeight: Int = getColumnIndexOrThrow(_stmt, "height")
        val _columnIndexOfHashHex: Int = getColumnIndexOrThrow(_stmt, "hashHex")
        val _columnIndexOfTotalDifficulty: Int = getColumnIndexOrThrow(_stmt, "totalDifficulty")
        val _columnIndexOfParentHash: Int = getColumnIndexOrThrow(_stmt, "parentHash")
        val _columnIndexOfUnclesHash: Int = getColumnIndexOrThrow(_stmt, "unclesHash")
        val _columnIndexOfCoinbase: Int = getColumnIndexOrThrow(_stmt, "coinbase")
        val _columnIndexOfStateRoot: Int = getColumnIndexOrThrow(_stmt, "stateRoot")
        val _columnIndexOfTransactionsRoot: Int = getColumnIndexOrThrow(_stmt, "transactionsRoot")
        val _columnIndexOfReceiptsRoot: Int = getColumnIndexOrThrow(_stmt, "receiptsRoot")
        val _columnIndexOfLogsBloom: Int = getColumnIndexOrThrow(_stmt, "logsBloom")
        val _columnIndexOfDifficulty: Int = getColumnIndexOrThrow(_stmt, "difficulty")
        val _columnIndexOfGasLimit: Int = getColumnIndexOrThrow(_stmt, "gasLimit")
        val _columnIndexOfGasUsed: Int = getColumnIndexOrThrow(_stmt, "gasUsed")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfExtraData: Int = getColumnIndexOrThrow(_stmt, "extraData")
        val _columnIndexOfMixHash: Int = getColumnIndexOrThrow(_stmt, "mixHash")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _result: MutableList<BlockHeader> = mutableListOf()
        while (_stmt.step()) {
          val _item: BlockHeader
          val _tmpHeight: Long
          _tmpHeight = _stmt.getLong(_columnIndexOfHeight)
          val _tmpHashHex: ByteArray
          _tmpHashHex = _stmt.getBlob(_columnIndexOfHashHex)
          val _tmpTotalDifficulty: BigInteger
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfTotalDifficulty)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfTotalDifficulty)
          }
          val _tmp_1: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTotalDifficulty = _tmp_1
          }
          val _tmpParentHash: ByteArray
          _tmpParentHash = _stmt.getBlob(_columnIndexOfParentHash)
          val _tmpUnclesHash: ByteArray
          _tmpUnclesHash = _stmt.getBlob(_columnIndexOfUnclesHash)
          val _tmpCoinbase: ByteArray
          _tmpCoinbase = _stmt.getBlob(_columnIndexOfCoinbase)
          val _tmpStateRoot: ByteArray
          _tmpStateRoot = _stmt.getBlob(_columnIndexOfStateRoot)
          val _tmpTransactionsRoot: ByteArray
          _tmpTransactionsRoot = _stmt.getBlob(_columnIndexOfTransactionsRoot)
          val _tmpReceiptsRoot: ByteArray
          _tmpReceiptsRoot = _stmt.getBlob(_columnIndexOfReceiptsRoot)
          val _tmpLogsBloom: ByteArray
          _tmpLogsBloom = _stmt.getBlob(_columnIndexOfLogsBloom)
          val _tmpDifficulty: ByteArray
          _tmpDifficulty = _stmt.getBlob(_columnIndexOfDifficulty)
          val _tmpGasLimit: ByteArray
          _tmpGasLimit = _stmt.getBlob(_columnIndexOfGasLimit)
          val _tmpGasUsed: Long
          _tmpGasUsed = _stmt.getLong(_columnIndexOfGasUsed)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpExtraData: ByteArray
          _tmpExtraData = _stmt.getBlob(_columnIndexOfExtraData)
          val _tmpMixHash: ByteArray
          _tmpMixHash = _stmt.getBlob(_columnIndexOfMixHash)
          val _tmpNonce: ByteArray
          _tmpNonce = _stmt.getBlob(_columnIndexOfNonce)
          _item =
              BlockHeader(_tmpHashHex,_tmpTotalDifficulty,_tmpParentHash,_tmpUnclesHash,_tmpCoinbase,_tmpStateRoot,_tmpTransactionsRoot,_tmpReceiptsRoot,_tmpLogsBloom,_tmpDifficulty,_tmpHeight,_tmpGasLimit,_tmpGasUsed,_tmpTimestamp,_tmpExtraData,_tmpMixHash,_tmpNonce)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
