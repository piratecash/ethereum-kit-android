package io.horizontalsystems.ethereumkit.core.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.models.Eip20SyncState
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class Eip20SyncStateDao_Impl(
  __db: RoomDatabase,
) : Eip20SyncStateDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfEip20SyncState: EntityInsertAdapter<Eip20SyncState>
  init {
    this.__db = __db
    this.__insertAdapterOfEip20SyncState = object : EntityInsertAdapter<Eip20SyncState>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `Eip20SyncState` (`contractAddress`,`lastScannedBlock`,`historicalMinScannedBlock`) VALUES (?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Eip20SyncState) {
        statement.bindText(1, entity.contractAddress)
        val _tmpLastScannedBlock: Long? = entity.lastScannedBlock
        if (_tmpLastScannedBlock == null) {
          statement.bindNull(2)
        } else {
          statement.bindLong(2, _tmpLastScannedBlock)
        }
        val _tmpHistoricalMinScannedBlock: Long? = entity.historicalMinScannedBlock
        if (_tmpHistoricalMinScannedBlock == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpHistoricalMinScannedBlock)
        }
      }
    }
  }

  public override fun insert(state: Eip20SyncState): Unit = performBlocking(__db, false, true) {
      _connection ->
    __insertAdapterOfEip20SyncState.insert(_connection, state)
  }

  public override fun `get`(contractAddress: String): Eip20SyncState? {
    val _sql: String = "SELECT * FROM Eip20SyncState WHERE contractAddress = ? LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, contractAddress)
        val _columnIndexOfContractAddress: Int = getColumnIndexOrThrow(_stmt, "contractAddress")
        val _columnIndexOfLastScannedBlock: Int = getColumnIndexOrThrow(_stmt, "lastScannedBlock")
        val _columnIndexOfHistoricalMinScannedBlock: Int = getColumnIndexOrThrow(_stmt,
            "historicalMinScannedBlock")
        val _result: Eip20SyncState?
        if (_stmt.step()) {
          val _tmpContractAddress: String
          _tmpContractAddress = _stmt.getText(_columnIndexOfContractAddress)
          val _tmpLastScannedBlock: Long?
          if (_stmt.isNull(_columnIndexOfLastScannedBlock)) {
            _tmpLastScannedBlock = null
          } else {
            _tmpLastScannedBlock = _stmt.getLong(_columnIndexOfLastScannedBlock)
          }
          val _tmpHistoricalMinScannedBlock: Long?
          if (_stmt.isNull(_columnIndexOfHistoricalMinScannedBlock)) {
            _tmpHistoricalMinScannedBlock = null
          } else {
            _tmpHistoricalMinScannedBlock = _stmt.getLong(_columnIndexOfHistoricalMinScannedBlock)
          }
          _result =
              Eip20SyncState(_tmpContractAddress,_tmpLastScannedBlock,_tmpHistoricalMinScannedBlock)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
