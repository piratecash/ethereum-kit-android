package io.horizontalsystems.ethereumkit.core.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.models.SyncSource
import io.horizontalsystems.ethereumkit.models.TransactionSyncSource
import javax.`annotation`.processing.Generated
import kotlin.ByteArray
import kotlin.IllegalArgumentException
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TransactionSyncSourceDao_Impl(
  __db: RoomDatabase,
) : TransactionSyncSourceDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTransactionSyncSource: EntityInsertAdapter<TransactionSyncSource>
  init {
    this.__db = __db
    this.__insertAdapterOfTransactionSyncSource = object :
        EntityInsertAdapter<TransactionSyncSource>() {
      protected override fun createQuery(): String =
          "INSERT OR IGNORE INTO `TransactionSyncSource` (`transactionHash`,`source`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TransactionSyncSource) {
        statement.bindBlob(1, entity.transactionHash)
        statement.bindText(2, __SyncSource_enumToString(entity.source))
      }
    }
  }

  public override fun insert(source: TransactionSyncSource): Unit = performBlocking(__db, false,
      true) { _connection ->
    __insertAdapterOfTransactionSyncSource.insert(_connection, source)
  }

  public override fun insertAll(sources: List<TransactionSyncSource>): Unit = performBlocking(__db,
      false, true) { _connection ->
    __insertAdapterOfTransactionSyncSource.insert(_connection, sources)
  }

  public override fun getSource(hash: ByteArray): TransactionSyncSource? {
    val _sql: String = "SELECT * FROM TransactionSyncSource WHERE transactionHash = ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindBlob(_argIndex, hash)
        val _columnIndexOfTransactionHash: Int = getColumnIndexOrThrow(_stmt, "transactionHash")
        val _columnIndexOfSource: Int = getColumnIndexOrThrow(_stmt, "source")
        val _result: TransactionSyncSource?
        if (_stmt.step()) {
          val _tmpTransactionHash: ByteArray
          _tmpTransactionHash = _stmt.getBlob(_columnIndexOfTransactionHash)
          val _tmpSource: SyncSource
          _tmpSource = __SyncSource_stringToEnum(_stmt.getText(_columnIndexOfSource))
          _result = TransactionSyncSource(_tmpTransactionHash,_tmpSource)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  private fun __SyncSource_enumToString(_value: SyncSource): String = when (_value) {
    SyncSource.ETHERSCAN -> "ETHERSCAN"
    SyncSource.ERC20_SYNCER -> "ERC20_SYNCER"
    SyncSource.MERKLE -> "MERKLE"
    SyncSource.RPC -> "RPC"
  }

  private fun __SyncSource_stringToEnum(_value: String): SyncSource = when (_value) {
    "ETHERSCAN" -> SyncSource.ETHERSCAN
    "ERC20_SYNCER" -> SyncSource.ERC20_SYNCER
    "MERKLE" -> SyncSource.MERKLE
    "RPC" -> SyncSource.RPC
    else -> throw IllegalArgumentException("Can't convert value to enum, unknown value: " + _value)
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
