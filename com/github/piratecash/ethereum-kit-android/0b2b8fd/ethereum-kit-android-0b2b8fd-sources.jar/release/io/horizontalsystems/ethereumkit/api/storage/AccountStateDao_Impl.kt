package io.horizontalsystems.ethereumkit.api.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.api.models.AccountState
import java.math.BigInteger
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class AccountStateDao_Impl(
  __db: RoomDatabase,
) : AccountStateDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfAccountState: EntityInsertAdapter<AccountState>

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()
  init {
    this.__db = __db
    this.__insertAdapterOfAccountState = object : EntityInsertAdapter<AccountState>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `AccountState` (`balance`,`nonce`,`id`) VALUES (?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: AccountState) {
        val _tmp: String? = __roomTypeConverters.bigIntegerToString(entity.balance)
        if (_tmp == null) {
          statement.bindNull(1)
        } else {
          statement.bindText(1, _tmp)
        }
        statement.bindLong(2, entity.nonce)
        statement.bindText(3, entity.id)
      }
    }
  }

  public override fun insert(accountState: AccountState): Unit = performBlocking(__db, false, true)
      { _connection ->
    __insertAdapterOfAccountState.insert(_connection, accountState)
  }

  public override fun getAccountState(): AccountState? {
    val _sql: String = "SELECT * FROM AccountState LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _result: AccountState?
        if (_stmt.step()) {
          val _tmpBalance: BigInteger
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfBalance)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfBalance)
          }
          val _tmp_1: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpBalance = _tmp_1
          }
          val _tmpNonce: Long
          _tmpNonce = _stmt.getLong(_columnIndexOfNonce)
          val _tmpId: String
          _tmpId = _stmt.getText(_columnIndexOfId)
          _result = AccountState(_tmpBalance,_tmpNonce,_tmpId)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
