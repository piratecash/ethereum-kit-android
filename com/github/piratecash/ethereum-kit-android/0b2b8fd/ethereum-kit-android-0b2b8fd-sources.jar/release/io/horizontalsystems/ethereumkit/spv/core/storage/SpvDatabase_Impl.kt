package io.horizontalsystems.ethereumkit.spv.core.storage

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class SpvDatabase_Impl : SpvDatabase() {
  private val _blockHeaderDao: Lazy<BlockHeaderDao> = lazy {
    BlockHeaderDao_Impl(this)
  }

  private val _accountStateDao: Lazy<AccountStateDao> = lazy {
    AccountStateDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(2,
        "7d7d7e36c6151a4abf7534a21e98cbc0", "cba695ff8cd382c1a7f4d7340e271432") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `BlockHeader` (`height` INTEGER NOT NULL, `hashHex` BLOB NOT NULL, `totalDifficulty` TEXT NOT NULL, `parentHash` BLOB NOT NULL, `unclesHash` BLOB NOT NULL, `coinbase` BLOB NOT NULL, `stateRoot` BLOB NOT NULL, `transactionsRoot` BLOB NOT NULL, `receiptsRoot` BLOB NOT NULL, `logsBloom` BLOB NOT NULL, `difficulty` BLOB NOT NULL, `gasLimit` BLOB NOT NULL, `gasUsed` INTEGER NOT NULL, `timestamp` INTEGER NOT NULL, `extraData` BLOB NOT NULL, `mixHash` BLOB NOT NULL, `nonce` BLOB NOT NULL, PRIMARY KEY(`height`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `AccountStateSpv` (`address` BLOB NOT NULL, `nonce` INTEGER NOT NULL, `balance` TEXT NOT NULL, `storageHash` BLOB NOT NULL, `codeHash` BLOB NOT NULL, PRIMARY KEY(`address`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '7d7d7e36c6151a4abf7534a21e98cbc0')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `BlockHeader`")
        connection.execSQL("DROP TABLE IF EXISTS `AccountStateSpv`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsBlockHeader: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsBlockHeader.put("height", TableInfo.Column("height", "INTEGER", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("hashHex", TableInfo.Column("hashHex", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("totalDifficulty", TableInfo.Column("totalDifficulty", "TEXT", true,
            0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("parentHash", TableInfo.Column("parentHash", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("unclesHash", TableInfo.Column("unclesHash", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("coinbase", TableInfo.Column("coinbase", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("stateRoot", TableInfo.Column("stateRoot", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("transactionsRoot", TableInfo.Column("transactionsRoot", "BLOB",
            true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("receiptsRoot", TableInfo.Column("receiptsRoot", "BLOB", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("logsBloom", TableInfo.Column("logsBloom", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("difficulty", TableInfo.Column("difficulty", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("gasLimit", TableInfo.Column("gasLimit", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("gasUsed", TableInfo.Column("gasUsed", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("timestamp", TableInfo.Column("timestamp", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("extraData", TableInfo.Column("extraData", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("mixHash", TableInfo.Column("mixHash", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBlockHeader.put("nonce", TableInfo.Column("nonce", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysBlockHeader: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesBlockHeader: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoBlockHeader: TableInfo = TableInfo("BlockHeader", _columnsBlockHeader,
            _foreignKeysBlockHeader, _indicesBlockHeader)
        val _existingBlockHeader: TableInfo = read(connection, "BlockHeader")
        if (!_infoBlockHeader.equals(_existingBlockHeader)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |BlockHeader(io.horizontalsystems.ethereumkit.spv.models.BlockHeader).
              | Expected:
              |""".trimMargin() + _infoBlockHeader + """
              |
              | Found:
              |""".trimMargin() + _existingBlockHeader)
        }
        val _columnsAccountStateSpv: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsAccountStateSpv.put("address", TableInfo.Column("address", "BLOB", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsAccountStateSpv.put("nonce", TableInfo.Column("nonce", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsAccountStateSpv.put("balance", TableInfo.Column("balance", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsAccountStateSpv.put("storageHash", TableInfo.Column("storageHash", "BLOB", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsAccountStateSpv.put("codeHash", TableInfo.Column("codeHash", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysAccountStateSpv: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesAccountStateSpv: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoAccountStateSpv: TableInfo = TableInfo("AccountStateSpv", _columnsAccountStateSpv,
            _foreignKeysAccountStateSpv, _indicesAccountStateSpv)
        val _existingAccountStateSpv: TableInfo = read(connection, "AccountStateSpv")
        if (!_infoAccountStateSpv.equals(_existingAccountStateSpv)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |AccountStateSpv(io.horizontalsystems.ethereumkit.spv.models.AccountStateSpv).
              | Expected:
              |""".trimMargin() + _infoAccountStateSpv + """
              |
              | Found:
              |""".trimMargin() + _existingAccountStateSpv)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "BlockHeader",
        "AccountStateSpv")
  }

  public override fun clearAllTables() {
    super.performClear(false, "BlockHeader", "AccountStateSpv")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(BlockHeaderDao::class, BlockHeaderDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(AccountStateDao::class, AccountStateDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun blockHeaderDao(): BlockHeaderDao = _blockHeaderDao.value

  public override fun accountStateDao(): AccountStateDao = _accountStateDao.value
}
