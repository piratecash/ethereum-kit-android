package io.horizontalsystems.ethereumkit.core.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.RoomRawQuery
import androidx.room.RoomSQLiteQuery
import androidx.room.RxRoom.Companion.createSingle
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndex
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import androidx.sqlite.db.SupportSQLiteQuery
import io.horizontalsystems.ethereumkit.api.storage.RoomTypeConverters
import io.horizontalsystems.ethereumkit.models.Address
import io.horizontalsystems.ethereumkit.models.InternalTransaction
import io.horizontalsystems.ethereumkit.models.Transaction
import io.reactivex.Single
import java.math.BigInteger
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.ByteArray
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TransactionDao_Impl(
  __db: RoomDatabase,
) : TransactionDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTransaction: EntityInsertAdapter<Transaction>

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()

  private val __insertAdapterOfInternalTransaction: EntityInsertAdapter<InternalTransaction>
  init {
    this.__db = __db
    this.__insertAdapterOfTransaction = object : EntityInsertAdapter<Transaction>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `Transaction` (`hash`,`timestamp`,`isFailed`,`blockNumber`,`transactionIndex`,`from`,`to`,`value`,`input`,`nonce`,`gasPrice`,`maxFeePerGas`,`maxPriorityFeePerGas`,`gasLimit`,`gasUsed`,`replacedWith`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Transaction) {
        statement.bindBlob(1, entity.hash)
        statement.bindLong(2, entity.timestamp)
        val _tmp: Int = if (entity.isFailed) 1 else 0
        statement.bindLong(3, _tmp.toLong())
        val _tmpBlockNumber: Long? = entity.blockNumber
        if (_tmpBlockNumber == null) {
          statement.bindNull(4)
        } else {
          statement.bindLong(4, _tmpBlockNumber)
        }
        val _tmpTransactionIndex: Int? = entity.transactionIndex
        if (_tmpTransactionIndex == null) {
          statement.bindNull(5)
        } else {
          statement.bindLong(5, _tmpTransactionIndex.toLong())
        }
        val _tmpFrom: Address? = entity.from
        val _tmp_1: ByteArray? = __roomTypeConverters.addressToByteArray(_tmpFrom)
        if (_tmp_1 == null) {
          statement.bindNull(6)
        } else {
          statement.bindBlob(6, _tmp_1)
        }
        val _tmpTo: Address? = entity.to
        val _tmp_2: ByteArray? = __roomTypeConverters.addressToByteArray(_tmpTo)
        if (_tmp_2 == null) {
          statement.bindNull(7)
        } else {
          statement.bindBlob(7, _tmp_2)
        }
        val _tmpValue: BigInteger? = entity.value
        val _tmp_3: String? = __roomTypeConverters.bigIntegerToString(_tmpValue)
        if (_tmp_3 == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmp_3)
        }
        val _tmpInput: ByteArray? = entity.input
        if (_tmpInput == null) {
          statement.bindNull(9)
        } else {
          statement.bindBlob(9, _tmpInput)
        }
        val _tmpNonce: Long? = entity.nonce
        if (_tmpNonce == null) {
          statement.bindNull(10)
        } else {
          statement.bindLong(10, _tmpNonce)
        }
        val _tmpGasPrice: Long? = entity.gasPrice
        if (_tmpGasPrice == null) {
          statement.bindNull(11)
        } else {
          statement.bindLong(11, _tmpGasPrice)
        }
        val _tmpMaxFeePerGas: Long? = entity.maxFeePerGas
        if (_tmpMaxFeePerGas == null) {
          statement.bindNull(12)
        } else {
          statement.bindLong(12, _tmpMaxFeePerGas)
        }
        val _tmpMaxPriorityFeePerGas: Long? = entity.maxPriorityFeePerGas
        if (_tmpMaxPriorityFeePerGas == null) {
          statement.bindNull(13)
        } else {
          statement.bindLong(13, _tmpMaxPriorityFeePerGas)
        }
        val _tmpGasLimit: Long? = entity.gasLimit
        if (_tmpGasLimit == null) {
          statement.bindNull(14)
        } else {
          statement.bindLong(14, _tmpGasLimit)
        }
        val _tmpGasUsed: Long? = entity.gasUsed
        if (_tmpGasUsed == null) {
          statement.bindNull(15)
        } else {
          statement.bindLong(15, _tmpGasUsed)
        }
        val _tmpReplacedWith: ByteArray? = entity.replacedWith
        if (_tmpReplacedWith == null) {
          statement.bindNull(16)
        } else {
          statement.bindBlob(16, _tmpReplacedWith)
        }
      }
    }
    this.__insertAdapterOfInternalTransaction = object : EntityInsertAdapter<InternalTransaction>()
        {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `InternalTransaction` (`hash`,`traceId`,`blockNumber`,`from`,`to`,`value`) VALUES (?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: InternalTransaction) {
        statement.bindBlob(1, entity.hash)
        statement.bindText(2, entity.traceId)
        statement.bindLong(3, entity.blockNumber)
        val _tmp: ByteArray? = __roomTypeConverters.addressToByteArray(entity.from)
        if (_tmp == null) {
          statement.bindNull(4)
        } else {
          statement.bindBlob(4, _tmp)
        }
        val _tmp_1: ByteArray? = __roomTypeConverters.addressToByteArray(entity.to)
        if (_tmp_1 == null) {
          statement.bindNull(5)
        } else {
          statement.bindBlob(5, _tmp_1)
        }
        val _tmp_2: String? = __roomTypeConverters.bigIntegerToString(entity.value)
        if (_tmp_2 == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmp_2)
        }
      }
    }
  }

  public override fun insert(transactions: List<Transaction>): Unit = performBlocking(__db, false,
      true) { _connection ->
    __insertAdapterOfTransaction.insert(_connection, transactions)
  }

  public override fun insertInternalTransactions(internalTransactions: List<InternalTransaction>):
      Unit = performBlocking(__db, false, true) { _connection ->
    __insertAdapterOfInternalTransaction.insert(_connection, internalTransactions)
  }

  public override fun getTransaction(hash: ByteArray): Transaction? {
    val _sql: String = "SELECT * FROM `Transaction` WHERE hash=?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindBlob(_argIndex, hash)
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfIsFailed: Int = getColumnIndexOrThrow(_stmt, "isFailed")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfTransactionIndex: Int = getColumnIndexOrThrow(_stmt, "transactionIndex")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfInput: Int = getColumnIndexOrThrow(_stmt, "input")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _columnIndexOfGasPrice: Int = getColumnIndexOrThrow(_stmt, "gasPrice")
        val _columnIndexOfMaxFeePerGas: Int = getColumnIndexOrThrow(_stmt, "maxFeePerGas")
        val _columnIndexOfMaxPriorityFeePerGas: Int = getColumnIndexOrThrow(_stmt,
            "maxPriorityFeePerGas")
        val _columnIndexOfGasLimit: Int = getColumnIndexOrThrow(_stmt, "gasLimit")
        val _columnIndexOfGasUsed: Int = getColumnIndexOrThrow(_stmt, "gasUsed")
        val _columnIndexOfReplacedWith: Int = getColumnIndexOrThrow(_stmt, "replacedWith")
        val _result: Transaction?
        if (_stmt.step()) {
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpIsFailed: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsFailed).toInt()
          _tmpIsFailed = _tmp != 0
          val _tmpBlockNumber: Long?
          if (_stmt.isNull(_columnIndexOfBlockNumber)) {
            _tmpBlockNumber = null
          } else {
            _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          }
          val _tmpTransactionIndex: Int?
          if (_stmt.isNull(_columnIndexOfTransactionIndex)) {
            _tmpTransactionIndex = null
          } else {
            _tmpTransactionIndex = _stmt.getLong(_columnIndexOfTransactionIndex).toInt()
          }
          val _tmpFrom: Address?
          val _tmp_1: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getBlob(_columnIndexOfFrom)
          }
          _tmpFrom = __roomTypeConverters.addressFromByteArray(_tmp_1)
          val _tmpTo: Address?
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfTo)
          }
          _tmpTo = __roomTypeConverters.addressFromByteArray(_tmp_2)
          val _tmpValue: BigInteger?
          val _tmp_3: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getText(_columnIndexOfValue)
          }
          _tmpValue = __roomTypeConverters.bigIntegerFromString(_tmp_3)
          val _tmpInput: ByteArray?
          if (_stmt.isNull(_columnIndexOfInput)) {
            _tmpInput = null
          } else {
            _tmpInput = _stmt.getBlob(_columnIndexOfInput)
          }
          val _tmpNonce: Long?
          if (_stmt.isNull(_columnIndexOfNonce)) {
            _tmpNonce = null
          } else {
            _tmpNonce = _stmt.getLong(_columnIndexOfNonce)
          }
          val _tmpGasPrice: Long?
          if (_stmt.isNull(_columnIndexOfGasPrice)) {
            _tmpGasPrice = null
          } else {
            _tmpGasPrice = _stmt.getLong(_columnIndexOfGasPrice)
          }
          val _tmpMaxFeePerGas: Long?
          if (_stmt.isNull(_columnIndexOfMaxFeePerGas)) {
            _tmpMaxFeePerGas = null
          } else {
            _tmpMaxFeePerGas = _stmt.getLong(_columnIndexOfMaxFeePerGas)
          }
          val _tmpMaxPriorityFeePerGas: Long?
          if (_stmt.isNull(_columnIndexOfMaxPriorityFeePerGas)) {
            _tmpMaxPriorityFeePerGas = null
          } else {
            _tmpMaxPriorityFeePerGas = _stmt.getLong(_columnIndexOfMaxPriorityFeePerGas)
          }
          val _tmpGasLimit: Long?
          if (_stmt.isNull(_columnIndexOfGasLimit)) {
            _tmpGasLimit = null
          } else {
            _tmpGasLimit = _stmt.getLong(_columnIndexOfGasLimit)
          }
          val _tmpGasUsed: Long?
          if (_stmt.isNull(_columnIndexOfGasUsed)) {
            _tmpGasUsed = null
          } else {
            _tmpGasUsed = _stmt.getLong(_columnIndexOfGasUsed)
          }
          val _tmpReplacedWith: ByteArray?
          if (_stmt.isNull(_columnIndexOfReplacedWith)) {
            _tmpReplacedWith = null
          } else {
            _tmpReplacedWith = _stmt.getBlob(_columnIndexOfReplacedWith)
          }
          _result =
              Transaction(_tmpHash,_tmpTimestamp,_tmpIsFailed,_tmpBlockNumber,_tmpTransactionIndex,_tmpFrom,_tmpTo,_tmpValue,_tmpInput,_tmpNonce,_tmpGasPrice,_tmpMaxFeePerGas,_tmpMaxPriorityFeePerGas,_tmpGasLimit,_tmpGasUsed,_tmpReplacedWith)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getLastInternalTransaction(): InternalTransaction? {
    val _sql: String = "SELECT * FROM `InternalTransaction` ORDER BY blockNumber DESC LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTraceId: Int = getColumnIndexOrThrow(_stmt, "traceId")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _result: InternalTransaction?
        if (_stmt.step()) {
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpTraceId: String
          _tmpTraceId = _stmt.getText(_columnIndexOfTraceId)
          val _tmpBlockNumber: Long
          _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          val _tmpFrom: Address
          val _tmp: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp = null
          } else {
            _tmp = _stmt.getBlob(_columnIndexOfFrom)
          }
          val _tmp_1: Address? = __roomTypeConverters.addressFromByteArray(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpFrom = _tmp_1
          }
          val _tmpTo: Address
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfTo)
          }
          val _tmp_3: Address? = __roomTypeConverters.addressFromByteArray(_tmp_2)
          if (_tmp_3 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpTo = _tmp_3
          }
          val _tmpValue: BigInteger
          val _tmp_4: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getText(_columnIndexOfValue)
          }
          val _tmp_5: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_4)
          if (_tmp_5 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpValue = _tmp_5
          }
          _result =
              InternalTransaction(_tmpHash,_tmpTraceId,_tmpBlockNumber,_tmpFrom,_tmpTo,_tmpValue)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getTransactions(hashes: List<ByteArray>): List<Transaction> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM `Transaction` WHERE hash IN (")
    val _inputSize: Int = hashes.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: ByteArray in hashes) {
          _stmt.bindBlob(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfIsFailed: Int = getColumnIndexOrThrow(_stmt, "isFailed")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfTransactionIndex: Int = getColumnIndexOrThrow(_stmt, "transactionIndex")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfInput: Int = getColumnIndexOrThrow(_stmt, "input")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _columnIndexOfGasPrice: Int = getColumnIndexOrThrow(_stmt, "gasPrice")
        val _columnIndexOfMaxFeePerGas: Int = getColumnIndexOrThrow(_stmt, "maxFeePerGas")
        val _columnIndexOfMaxPriorityFeePerGas: Int = getColumnIndexOrThrow(_stmt,
            "maxPriorityFeePerGas")
        val _columnIndexOfGasLimit: Int = getColumnIndexOrThrow(_stmt, "gasLimit")
        val _columnIndexOfGasUsed: Int = getColumnIndexOrThrow(_stmt, "gasUsed")
        val _columnIndexOfReplacedWith: Int = getColumnIndexOrThrow(_stmt, "replacedWith")
        val _result: MutableList<Transaction> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: Transaction
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpIsFailed: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsFailed).toInt()
          _tmpIsFailed = _tmp != 0
          val _tmpBlockNumber: Long?
          if (_stmt.isNull(_columnIndexOfBlockNumber)) {
            _tmpBlockNumber = null
          } else {
            _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          }
          val _tmpTransactionIndex: Int?
          if (_stmt.isNull(_columnIndexOfTransactionIndex)) {
            _tmpTransactionIndex = null
          } else {
            _tmpTransactionIndex = _stmt.getLong(_columnIndexOfTransactionIndex).toInt()
          }
          val _tmpFrom: Address?
          val _tmp_1: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getBlob(_columnIndexOfFrom)
          }
          _tmpFrom = __roomTypeConverters.addressFromByteArray(_tmp_1)
          val _tmpTo: Address?
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfTo)
          }
          _tmpTo = __roomTypeConverters.addressFromByteArray(_tmp_2)
          val _tmpValue: BigInteger?
          val _tmp_3: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getText(_columnIndexOfValue)
          }
          _tmpValue = __roomTypeConverters.bigIntegerFromString(_tmp_3)
          val _tmpInput: ByteArray?
          if (_stmt.isNull(_columnIndexOfInput)) {
            _tmpInput = null
          } else {
            _tmpInput = _stmt.getBlob(_columnIndexOfInput)
          }
          val _tmpNonce: Long?
          if (_stmt.isNull(_columnIndexOfNonce)) {
            _tmpNonce = null
          } else {
            _tmpNonce = _stmt.getLong(_columnIndexOfNonce)
          }
          val _tmpGasPrice: Long?
          if (_stmt.isNull(_columnIndexOfGasPrice)) {
            _tmpGasPrice = null
          } else {
            _tmpGasPrice = _stmt.getLong(_columnIndexOfGasPrice)
          }
          val _tmpMaxFeePerGas: Long?
          if (_stmt.isNull(_columnIndexOfMaxFeePerGas)) {
            _tmpMaxFeePerGas = null
          } else {
            _tmpMaxFeePerGas = _stmt.getLong(_columnIndexOfMaxFeePerGas)
          }
          val _tmpMaxPriorityFeePerGas: Long?
          if (_stmt.isNull(_columnIndexOfMaxPriorityFeePerGas)) {
            _tmpMaxPriorityFeePerGas = null
          } else {
            _tmpMaxPriorityFeePerGas = _stmt.getLong(_columnIndexOfMaxPriorityFeePerGas)
          }
          val _tmpGasLimit: Long?
          if (_stmt.isNull(_columnIndexOfGasLimit)) {
            _tmpGasLimit = null
          } else {
            _tmpGasLimit = _stmt.getLong(_columnIndexOfGasLimit)
          }
          val _tmpGasUsed: Long?
          if (_stmt.isNull(_columnIndexOfGasUsed)) {
            _tmpGasUsed = null
          } else {
            _tmpGasUsed = _stmt.getLong(_columnIndexOfGasUsed)
          }
          val _tmpReplacedWith: ByteArray?
          if (_stmt.isNull(_columnIndexOfReplacedWith)) {
            _tmpReplacedWith = null
          } else {
            _tmpReplacedWith = _stmt.getBlob(_columnIndexOfReplacedWith)
          }
          _item_1 =
              Transaction(_tmpHash,_tmpTimestamp,_tmpIsFailed,_tmpBlockNumber,_tmpTransactionIndex,_tmpFrom,_tmpTo,_tmpValue,_tmpInput,_tmpNonce,_tmpGasPrice,_tmpMaxFeePerGas,_tmpMaxPriorityFeePerGas,_tmpGasLimit,_tmpGasUsed,_tmpReplacedWith)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getPendingTransactions(): List<Transaction> {
    val _sql: String = "SELECT * FROM `Transaction` WHERE blockNumber IS NULL AND isFailed IS 0"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfIsFailed: Int = getColumnIndexOrThrow(_stmt, "isFailed")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfTransactionIndex: Int = getColumnIndexOrThrow(_stmt, "transactionIndex")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfInput: Int = getColumnIndexOrThrow(_stmt, "input")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _columnIndexOfGasPrice: Int = getColumnIndexOrThrow(_stmt, "gasPrice")
        val _columnIndexOfMaxFeePerGas: Int = getColumnIndexOrThrow(_stmt, "maxFeePerGas")
        val _columnIndexOfMaxPriorityFeePerGas: Int = getColumnIndexOrThrow(_stmt,
            "maxPriorityFeePerGas")
        val _columnIndexOfGasLimit: Int = getColumnIndexOrThrow(_stmt, "gasLimit")
        val _columnIndexOfGasUsed: Int = getColumnIndexOrThrow(_stmt, "gasUsed")
        val _columnIndexOfReplacedWith: Int = getColumnIndexOrThrow(_stmt, "replacedWith")
        val _result: MutableList<Transaction> = mutableListOf()
        while (_stmt.step()) {
          val _item: Transaction
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpIsFailed: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsFailed).toInt()
          _tmpIsFailed = _tmp != 0
          val _tmpBlockNumber: Long?
          if (_stmt.isNull(_columnIndexOfBlockNumber)) {
            _tmpBlockNumber = null
          } else {
            _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          }
          val _tmpTransactionIndex: Int?
          if (_stmt.isNull(_columnIndexOfTransactionIndex)) {
            _tmpTransactionIndex = null
          } else {
            _tmpTransactionIndex = _stmt.getLong(_columnIndexOfTransactionIndex).toInt()
          }
          val _tmpFrom: Address?
          val _tmp_1: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getBlob(_columnIndexOfFrom)
          }
          _tmpFrom = __roomTypeConverters.addressFromByteArray(_tmp_1)
          val _tmpTo: Address?
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfTo)
          }
          _tmpTo = __roomTypeConverters.addressFromByteArray(_tmp_2)
          val _tmpValue: BigInteger?
          val _tmp_3: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getText(_columnIndexOfValue)
          }
          _tmpValue = __roomTypeConverters.bigIntegerFromString(_tmp_3)
          val _tmpInput: ByteArray?
          if (_stmt.isNull(_columnIndexOfInput)) {
            _tmpInput = null
          } else {
            _tmpInput = _stmt.getBlob(_columnIndexOfInput)
          }
          val _tmpNonce: Long?
          if (_stmt.isNull(_columnIndexOfNonce)) {
            _tmpNonce = null
          } else {
            _tmpNonce = _stmt.getLong(_columnIndexOfNonce)
          }
          val _tmpGasPrice: Long?
          if (_stmt.isNull(_columnIndexOfGasPrice)) {
            _tmpGasPrice = null
          } else {
            _tmpGasPrice = _stmt.getLong(_columnIndexOfGasPrice)
          }
          val _tmpMaxFeePerGas: Long?
          if (_stmt.isNull(_columnIndexOfMaxFeePerGas)) {
            _tmpMaxFeePerGas = null
          } else {
            _tmpMaxFeePerGas = _stmt.getLong(_columnIndexOfMaxFeePerGas)
          }
          val _tmpMaxPriorityFeePerGas: Long?
          if (_stmt.isNull(_columnIndexOfMaxPriorityFeePerGas)) {
            _tmpMaxPriorityFeePerGas = null
          } else {
            _tmpMaxPriorityFeePerGas = _stmt.getLong(_columnIndexOfMaxPriorityFeePerGas)
          }
          val _tmpGasLimit: Long?
          if (_stmt.isNull(_columnIndexOfGasLimit)) {
            _tmpGasLimit = null
          } else {
            _tmpGasLimit = _stmt.getLong(_columnIndexOfGasLimit)
          }
          val _tmpGasUsed: Long?
          if (_stmt.isNull(_columnIndexOfGasUsed)) {
            _tmpGasUsed = null
          } else {
            _tmpGasUsed = _stmt.getLong(_columnIndexOfGasUsed)
          }
          val _tmpReplacedWith: ByteArray?
          if (_stmt.isNull(_columnIndexOfReplacedWith)) {
            _tmpReplacedWith = null
          } else {
            _tmpReplacedWith = _stmt.getBlob(_columnIndexOfReplacedWith)
          }
          _item =
              Transaction(_tmpHash,_tmpTimestamp,_tmpIsFailed,_tmpBlockNumber,_tmpTransactionIndex,_tmpFrom,_tmpTo,_tmpValue,_tmpInput,_tmpNonce,_tmpGasPrice,_tmpMaxFeePerGas,_tmpMaxPriorityFeePerGas,_tmpGasLimit,_tmpGasUsed,_tmpReplacedWith)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getNonPendingByNonces(from: ByteArray, nonces: List<Long>):
      List<Transaction> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM `Transaction` WHERE blockNumber IS NOT NULL AND nonce IN (")
    val _inputSize: Int = nonces.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND `from`=")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in nonces) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindBlob(_argIndex, from)
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfIsFailed: Int = getColumnIndexOrThrow(_stmt, "isFailed")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfTransactionIndex: Int = getColumnIndexOrThrow(_stmt, "transactionIndex")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfInput: Int = getColumnIndexOrThrow(_stmt, "input")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _columnIndexOfGasPrice: Int = getColumnIndexOrThrow(_stmt, "gasPrice")
        val _columnIndexOfMaxFeePerGas: Int = getColumnIndexOrThrow(_stmt, "maxFeePerGas")
        val _columnIndexOfMaxPriorityFeePerGas: Int = getColumnIndexOrThrow(_stmt,
            "maxPriorityFeePerGas")
        val _columnIndexOfGasLimit: Int = getColumnIndexOrThrow(_stmt, "gasLimit")
        val _columnIndexOfGasUsed: Int = getColumnIndexOrThrow(_stmt, "gasUsed")
        val _columnIndexOfReplacedWith: Int = getColumnIndexOrThrow(_stmt, "replacedWith")
        val _result: MutableList<Transaction> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: Transaction
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpIsFailed: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsFailed).toInt()
          _tmpIsFailed = _tmp != 0
          val _tmpBlockNumber: Long?
          if (_stmt.isNull(_columnIndexOfBlockNumber)) {
            _tmpBlockNumber = null
          } else {
            _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          }
          val _tmpTransactionIndex: Int?
          if (_stmt.isNull(_columnIndexOfTransactionIndex)) {
            _tmpTransactionIndex = null
          } else {
            _tmpTransactionIndex = _stmt.getLong(_columnIndexOfTransactionIndex).toInt()
          }
          val _tmpFrom: Address?
          val _tmp_1: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getBlob(_columnIndexOfFrom)
          }
          _tmpFrom = __roomTypeConverters.addressFromByteArray(_tmp_1)
          val _tmpTo: Address?
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfTo)
          }
          _tmpTo = __roomTypeConverters.addressFromByteArray(_tmp_2)
          val _tmpValue: BigInteger?
          val _tmp_3: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getText(_columnIndexOfValue)
          }
          _tmpValue = __roomTypeConverters.bigIntegerFromString(_tmp_3)
          val _tmpInput: ByteArray?
          if (_stmt.isNull(_columnIndexOfInput)) {
            _tmpInput = null
          } else {
            _tmpInput = _stmt.getBlob(_columnIndexOfInput)
          }
          val _tmpNonce: Long?
          if (_stmt.isNull(_columnIndexOfNonce)) {
            _tmpNonce = null
          } else {
            _tmpNonce = _stmt.getLong(_columnIndexOfNonce)
          }
          val _tmpGasPrice: Long?
          if (_stmt.isNull(_columnIndexOfGasPrice)) {
            _tmpGasPrice = null
          } else {
            _tmpGasPrice = _stmt.getLong(_columnIndexOfGasPrice)
          }
          val _tmpMaxFeePerGas: Long?
          if (_stmt.isNull(_columnIndexOfMaxFeePerGas)) {
            _tmpMaxFeePerGas = null
          } else {
            _tmpMaxFeePerGas = _stmt.getLong(_columnIndexOfMaxFeePerGas)
          }
          val _tmpMaxPriorityFeePerGas: Long?
          if (_stmt.isNull(_columnIndexOfMaxPriorityFeePerGas)) {
            _tmpMaxPriorityFeePerGas = null
          } else {
            _tmpMaxPriorityFeePerGas = _stmt.getLong(_columnIndexOfMaxPriorityFeePerGas)
          }
          val _tmpGasLimit: Long?
          if (_stmt.isNull(_columnIndexOfGasLimit)) {
            _tmpGasLimit = null
          } else {
            _tmpGasLimit = _stmt.getLong(_columnIndexOfGasLimit)
          }
          val _tmpGasUsed: Long?
          if (_stmt.isNull(_columnIndexOfGasUsed)) {
            _tmpGasUsed = null
          } else {
            _tmpGasUsed = _stmt.getLong(_columnIndexOfGasUsed)
          }
          val _tmpReplacedWith: ByteArray?
          if (_stmt.isNull(_columnIndexOfReplacedWith)) {
            _tmpReplacedWith = null
          } else {
            _tmpReplacedWith = _stmt.getBlob(_columnIndexOfReplacedWith)
          }
          _item_1 =
              Transaction(_tmpHash,_tmpTimestamp,_tmpIsFailed,_tmpBlockNumber,_tmpTransactionIndex,_tmpFrom,_tmpTo,_tmpValue,_tmpInput,_tmpNonce,_tmpGasPrice,_tmpMaxFeePerGas,_tmpMaxPriorityFeePerGas,_tmpGasLimit,_tmpGasUsed,_tmpReplacedWith)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getInternalTransactions(): List<InternalTransaction> {
    val _sql: String = "SELECT * FROM `InternalTransaction`"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTraceId: Int = getColumnIndexOrThrow(_stmt, "traceId")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _result: MutableList<InternalTransaction> = mutableListOf()
        while (_stmt.step()) {
          val _item: InternalTransaction
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpTraceId: String
          _tmpTraceId = _stmt.getText(_columnIndexOfTraceId)
          val _tmpBlockNumber: Long
          _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          val _tmpFrom: Address
          val _tmp: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp = null
          } else {
            _tmp = _stmt.getBlob(_columnIndexOfFrom)
          }
          val _tmp_1: Address? = __roomTypeConverters.addressFromByteArray(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpFrom = _tmp_1
          }
          val _tmpTo: Address
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfTo)
          }
          val _tmp_3: Address? = __roomTypeConverters.addressFromByteArray(_tmp_2)
          if (_tmp_3 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpTo = _tmp_3
          }
          val _tmpValue: BigInteger
          val _tmp_4: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getText(_columnIndexOfValue)
          }
          val _tmp_5: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_4)
          if (_tmp_5 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpValue = _tmp_5
          }
          _item =
              InternalTransaction(_tmpHash,_tmpTraceId,_tmpBlockNumber,_tmpFrom,_tmpTo,_tmpValue)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getInternalTransactionsByHashes(hashes: List<ByteArray>):
      List<InternalTransaction> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM `InternalTransaction` WHERE hash IN (")
    val _inputSize: Int = hashes.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: ByteArray in hashes) {
          _stmt.bindBlob(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTraceId: Int = getColumnIndexOrThrow(_stmt, "traceId")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _result: MutableList<InternalTransaction> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: InternalTransaction
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpTraceId: String
          _tmpTraceId = _stmt.getText(_columnIndexOfTraceId)
          val _tmpBlockNumber: Long
          _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          val _tmpFrom: Address
          val _tmp: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp = null
          } else {
            _tmp = _stmt.getBlob(_columnIndexOfFrom)
          }
          val _tmp_1: Address? = __roomTypeConverters.addressFromByteArray(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpFrom = _tmp_1
          }
          val _tmpTo: Address
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfTo)
          }
          val _tmp_3: Address? = __roomTypeConverters.addressFromByteArray(_tmp_2)
          if (_tmp_3 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpTo = _tmp_3
          }
          val _tmpValue: BigInteger
          val _tmp_4: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getText(_columnIndexOfValue)
          }
          val _tmp_5: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_4)
          if (_tmp_5 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpValue = _tmp_5
          }
          _item_1 =
              InternalTransaction(_tmpHash,_tmpTraceId,_tmpBlockNumber,_tmpFrom,_tmpTo,_tmpValue)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getTransactionsByRawQuery(query: SupportSQLiteQuery):
      Single<List<Transaction>> {
    val _rawQuery: RoomRawQuery = RoomSQLiteQuery.copyFrom(query).toRoomRawQuery()
    val _sql: String = _rawQuery.sql
    return createSingle(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _rawQuery.getBindingFunction().invoke(_stmt)
        val _result: MutableList<Transaction> = mutableListOf()
        while (_stmt.step()) {
          val _item: Transaction
          _item = __entityStatementConverter_ioHorizontalsystemsEthereumkitModelsTransaction(_stmt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getPending(query: SupportSQLiteQuery): List<Transaction> {
    val _rawQuery: RoomRawQuery = RoomSQLiteQuery.copyFrom(query).toRoomRawQuery()
    val _sql: String = _rawQuery.sql
    return performBlocking(__db, true, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _rawQuery.getBindingFunction().invoke(_stmt)
        val _result: MutableList<Transaction> = mutableListOf()
        while (_stmt.step()) {
          val _item: Transaction
          _item = __entityStatementConverter_ioHorizontalsystemsEthereumkitModelsTransaction(_stmt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  private
      fun __entityStatementConverter_ioHorizontalsystemsEthereumkitModelsTransaction(statement: SQLiteStatement):
      Transaction {
    val _entity: Transaction
    val _columnIndexOfHash: Int = getColumnIndex(statement, "hash")
    val _columnIndexOfTimestamp: Int = getColumnIndex(statement, "timestamp")
    val _columnIndexOfIsFailed: Int = getColumnIndex(statement, "isFailed")
    val _columnIndexOfBlockNumber: Int = getColumnIndex(statement, "blockNumber")
    val _columnIndexOfTransactionIndex: Int = getColumnIndex(statement, "transactionIndex")
    val _columnIndexOfFrom: Int = getColumnIndex(statement, "from")
    val _columnIndexOfTo: Int = getColumnIndex(statement, "to")
    val _columnIndexOfValue: Int = getColumnIndex(statement, "value")
    val _columnIndexOfInput: Int = getColumnIndex(statement, "input")
    val _columnIndexOfNonce: Int = getColumnIndex(statement, "nonce")
    val _columnIndexOfGasPrice: Int = getColumnIndex(statement, "gasPrice")
    val _columnIndexOfMaxFeePerGas: Int = getColumnIndex(statement, "maxFeePerGas")
    val _columnIndexOfMaxPriorityFeePerGas: Int = getColumnIndex(statement, "maxPriorityFeePerGas")
    val _columnIndexOfGasLimit: Int = getColumnIndex(statement, "gasLimit")
    val _columnIndexOfGasUsed: Int = getColumnIndex(statement, "gasUsed")
    val _columnIndexOfReplacedWith: Int = getColumnIndex(statement, "replacedWith")
    val _tmpHash: ByteArray
    if (_columnIndexOfHash == -1) {
      error("Missing value for a NON-NULL column 'hash', found NULL value instead.")
    } else {
      _tmpHash = statement.getBlob(_columnIndexOfHash)
    }
    val _tmpTimestamp: Long
    if (_columnIndexOfTimestamp == -1) {
      _tmpTimestamp = 0
    } else {
      _tmpTimestamp = statement.getLong(_columnIndexOfTimestamp)
    }
    val _tmpIsFailed: Boolean
    if (_columnIndexOfIsFailed == -1) {
      _tmpIsFailed = false
    } else {
      val _tmp: Int
      _tmp = statement.getLong(_columnIndexOfIsFailed).toInt()
      _tmpIsFailed = _tmp != 0
    }
    val _tmpBlockNumber: Long?
    if (_columnIndexOfBlockNumber == -1) {
      _tmpBlockNumber = null
    } else {
      if (statement.isNull(_columnIndexOfBlockNumber)) {
        _tmpBlockNumber = null
      } else {
        _tmpBlockNumber = statement.getLong(_columnIndexOfBlockNumber)
      }
    }
    val _tmpTransactionIndex: Int?
    if (_columnIndexOfTransactionIndex == -1) {
      _tmpTransactionIndex = null
    } else {
      if (statement.isNull(_columnIndexOfTransactionIndex)) {
        _tmpTransactionIndex = null
      } else {
        _tmpTransactionIndex = statement.getLong(_columnIndexOfTransactionIndex).toInt()
      }
    }
    val _tmpFrom: Address?
    if (_columnIndexOfFrom == -1) {
      _tmpFrom = null
    } else {
      val _tmp_1: ByteArray?
      if (statement.isNull(_columnIndexOfFrom)) {
        _tmp_1 = null
      } else {
        _tmp_1 = statement.getBlob(_columnIndexOfFrom)
      }
      _tmpFrom = __roomTypeConverters.addressFromByteArray(_tmp_1)
    }
    val _tmpTo: Address?
    if (_columnIndexOfTo == -1) {
      _tmpTo = null
    } else {
      val _tmp_2: ByteArray?
      if (statement.isNull(_columnIndexOfTo)) {
        _tmp_2 = null
      } else {
        _tmp_2 = statement.getBlob(_columnIndexOfTo)
      }
      _tmpTo = __roomTypeConverters.addressFromByteArray(_tmp_2)
    }
    val _tmpValue: BigInteger?
    if (_columnIndexOfValue == -1) {
      _tmpValue = null
    } else {
      val _tmp_3: String?
      if (statement.isNull(_columnIndexOfValue)) {
        _tmp_3 = null
      } else {
        _tmp_3 = statement.getText(_columnIndexOfValue)
      }
      _tmpValue = __roomTypeConverters.bigIntegerFromString(_tmp_3)
    }
    val _tmpInput: ByteArray?
    if (_columnIndexOfInput == -1) {
      _tmpInput = null
    } else {
      if (statement.isNull(_columnIndexOfInput)) {
        _tmpInput = null
      } else {
        _tmpInput = statement.getBlob(_columnIndexOfInput)
      }
    }
    val _tmpNonce: Long?
    if (_columnIndexOfNonce == -1) {
      _tmpNonce = null
    } else {
      if (statement.isNull(_columnIndexOfNonce)) {
        _tmpNonce = null
      } else {
        _tmpNonce = statement.getLong(_columnIndexOfNonce)
      }
    }
    val _tmpGasPrice: Long?
    if (_columnIndexOfGasPrice == -1) {
      _tmpGasPrice = null
    } else {
      if (statement.isNull(_columnIndexOfGasPrice)) {
        _tmpGasPrice = null
      } else {
        _tmpGasPrice = statement.getLong(_columnIndexOfGasPrice)
      }
    }
    val _tmpMaxFeePerGas: Long?
    if (_columnIndexOfMaxFeePerGas == -1) {
      _tmpMaxFeePerGas = null
    } else {
      if (statement.isNull(_columnIndexOfMaxFeePerGas)) {
        _tmpMaxFeePerGas = null
      } else {
        _tmpMaxFeePerGas = statement.getLong(_columnIndexOfMaxFeePerGas)
      }
    }
    val _tmpMaxPriorityFeePerGas: Long?
    if (_columnIndexOfMaxPriorityFeePerGas == -1) {
      _tmpMaxPriorityFeePerGas = null
    } else {
      if (statement.isNull(_columnIndexOfMaxPriorityFeePerGas)) {
        _tmpMaxPriorityFeePerGas = null
      } else {
        _tmpMaxPriorityFeePerGas = statement.getLong(_columnIndexOfMaxPriorityFeePerGas)
      }
    }
    val _tmpGasLimit: Long?
    if (_columnIndexOfGasLimit == -1) {
      _tmpGasLimit = null
    } else {
      if (statement.isNull(_columnIndexOfGasLimit)) {
        _tmpGasLimit = null
      } else {
        _tmpGasLimit = statement.getLong(_columnIndexOfGasLimit)
      }
    }
    val _tmpGasUsed: Long?
    if (_columnIndexOfGasUsed == -1) {
      _tmpGasUsed = null
    } else {
      if (statement.isNull(_columnIndexOfGasUsed)) {
        _tmpGasUsed = null
      } else {
        _tmpGasUsed = statement.getLong(_columnIndexOfGasUsed)
      }
    }
    val _tmpReplacedWith: ByteArray?
    if (_columnIndexOfReplacedWith == -1) {
      _tmpReplacedWith = null
    } else {
      if (statement.isNull(_columnIndexOfReplacedWith)) {
        _tmpReplacedWith = null
      } else {
        _tmpReplacedWith = statement.getBlob(_columnIndexOfReplacedWith)
      }
    }
    _entity =
        Transaction(_tmpHash,_tmpTimestamp,_tmpIsFailed,_tmpBlockNumber,_tmpTransactionIndex,_tmpFrom,_tmpTo,_tmpValue,_tmpInput,_tmpNonce,_tmpGasPrice,_tmpMaxFeePerGas,_tmpMaxPriorityFeePerGas,_tmpGasLimit,_tmpGasUsed,_tmpReplacedWith)
    return _entity
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
