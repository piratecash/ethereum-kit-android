package io.horizontalsystems.ethereumkit.core.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.models.TransactionTag
import javax.`annotation`.processing.Generated
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TransactionTagDao_Impl(
  __db: RoomDatabase,
) : TransactionTagDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTransactionTag: EntityInsertAdapter<TransactionTag>
  init {
    this.__db = __db
    this.__insertAdapterOfTransactionTag = object : EntityInsertAdapter<TransactionTag>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `TransactionTag` (`name`,`hash`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TransactionTag) {
        statement.bindText(1, entity.name)
        statement.bindBlob(2, entity.hash)
      }
    }
  }

  public override fun insert(tags: List<TransactionTag>): Unit = performBlocking(__db, false, true)
      { _connection ->
    __insertAdapterOfTransactionTag.insert(_connection, tags)
  }

  public override fun getDistinctTokenContractAddresses(): List<String> {
    val _sql: String =
        "SELECT DISTINCT name FROM TransactionTag WHERE name LIKE '%_outgoing' OR name LIKE '%_incoming'"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
