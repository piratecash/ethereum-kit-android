package io.horizontalsystems.ethereumkit.api.storage

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class ApiDatabase_Impl : ApiDatabase() {
  private val _accountStateDao: Lazy<AccountStateDao> = lazy {
    AccountStateDao_Impl(this)
  }

  private val _lastBlockHeightDao: Lazy<LastBlockHeightDao> = lazy {
    LastBlockHeightDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(3,
        "f07c2ec1506b0934782433fa119aaa1c", "ca804200595532b44fbc97833167f5a7") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `AccountState` (`balance` TEXT NOT NULL, `nonce` INTEGER NOT NULL, `id` TEXT NOT NULL, PRIMARY KEY(`id`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `LastBlockHeight` (`height` INTEGER NOT NULL, `id` TEXT NOT NULL, PRIMARY KEY(`id`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'f07c2ec1506b0934782433fa119aaa1c')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `AccountState`")
        connection.execSQL("DROP TABLE IF EXISTS `LastBlockHeight`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsAccountState: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsAccountState.put("balance", TableInfo.Column("balance", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsAccountState.put("nonce", TableInfo.Column("nonce", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsAccountState.put("id", TableInfo.Column("id", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysAccountState: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesAccountState: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoAccountState: TableInfo = TableInfo("AccountState", _columnsAccountState,
            _foreignKeysAccountState, _indicesAccountState)
        val _existingAccountState: TableInfo = read(connection, "AccountState")
        if (!_infoAccountState.equals(_existingAccountState)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |AccountState(io.horizontalsystems.ethereumkit.api.models.AccountState).
              | Expected:
              |""".trimMargin() + _infoAccountState + """
              |
              | Found:
              |""".trimMargin() + _existingAccountState)
        }
        val _columnsLastBlockHeight: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsLastBlockHeight.put("height", TableInfo.Column("height", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsLastBlockHeight.put("id", TableInfo.Column("id", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysLastBlockHeight: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesLastBlockHeight: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoLastBlockHeight: TableInfo = TableInfo("LastBlockHeight", _columnsLastBlockHeight,
            _foreignKeysLastBlockHeight, _indicesLastBlockHeight)
        val _existingLastBlockHeight: TableInfo = read(connection, "LastBlockHeight")
        if (!_infoLastBlockHeight.equals(_existingLastBlockHeight)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |LastBlockHeight(io.horizontalsystems.ethereumkit.api.models.LastBlockHeight).
              | Expected:
              |""".trimMargin() + _infoLastBlockHeight + """
              |
              | Found:
              |""".trimMargin() + _existingLastBlockHeight)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "AccountState",
        "LastBlockHeight")
  }

  public override fun clearAllTables() {
    super.performClear(false, "AccountState", "LastBlockHeight")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(AccountStateDao::class, AccountStateDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(LastBlockHeightDao::class,
        LastBlockHeightDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun balanceDao(): AccountStateDao = _accountStateDao.value

  public override fun lastBlockHeightDao(): LastBlockHeightDao = _lastBlockHeightDao.value
}
