package io.horizontalsystems.ethereumkit.core.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.models.TransactionSyncerState
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TransactionSyncerStateDao_Impl(
  __db: RoomDatabase,
) : TransactionSyncerStateDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTransactionSyncerState: EntityInsertAdapter<TransactionSyncerState>
  init {
    this.__db = __db
    this.__insertAdapterOfTransactionSyncerState = object :
        EntityInsertAdapter<TransactionSyncerState>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `TransactionSyncerState` (`syncerId`,`lastBlockNumber`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TransactionSyncerState) {
        statement.bindText(1, entity.syncerId)
        statement.bindLong(2, entity.lastBlockNumber)
      }
    }
  }

  public override fun save(transactionSyncerState: TransactionSyncerState): Unit =
      performBlocking(__db, false, true) { _connection ->
    __insertAdapterOfTransactionSyncerState.insert(_connection, transactionSyncerState)
  }

  public override fun `get`(syncerId: String): TransactionSyncerState? {
    val _sql: String = "SELECT * FROM `TransactionSyncerState` WHERE syncerId = ? LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, syncerId)
        val _columnIndexOfSyncerId: Int = getColumnIndexOrThrow(_stmt, "syncerId")
        val _columnIndexOfLastBlockNumber: Int = getColumnIndexOrThrow(_stmt, "lastBlockNumber")
        val _result: TransactionSyncerState?
        if (_stmt.step()) {
          val _tmpSyncerId: String
          _tmpSyncerId = _stmt.getText(_columnIndexOfSyncerId)
          val _tmpLastBlockNumber: Long
          _tmpLastBlockNumber = _stmt.getLong(_columnIndexOfLastBlockNumber)
          _result = TransactionSyncerState(_tmpSyncerId,_tmpLastBlockNumber)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
