package io.horizontalsystems.ethereumkit.core.storage

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class Eip20Database_Impl : Eip20Database() {
  private val _eip20EventDao: Lazy<Eip20EventDao> = lazy {
    Eip20EventDao_Impl(this)
  }

  private val _eip20SyncStateDao: Lazy<Eip20SyncStateDao> = lazy {
    Eip20SyncStateDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(6,
        "59379eaf43667900b738fa945e9ab8a0", "2ffe54f92863224d5df455cc2d8798c7") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `Eip20Event` (`hash` BLOB NOT NULL, `blockNumber` INTEGER NOT NULL, `contractAddress` BLOB NOT NULL, `from` BLOB NOT NULL, `to` BLOB NOT NULL, `value` TEXT NOT NULL, `tokenName` TEXT NOT NULL, `tokenSymbol` TEXT NOT NULL, `tokenDecimal` INTEGER NOT NULL, PRIMARY KEY(`hash`, `contractAddress`, `from`, `to`, `value`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `Eip20SyncState` (`contractAddress` TEXT NOT NULL, `lastScannedBlock` INTEGER, `historicalMinScannedBlock` INTEGER, PRIMARY KEY(`contractAddress`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '59379eaf43667900b738fa945e9ab8a0')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `Eip20Event`")
        connection.execSQL("DROP TABLE IF EXISTS `Eip20SyncState`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsEip20Event: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsEip20Event.put("hash", TableInfo.Column("hash", "BLOB", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20Event.put("blockNumber", TableInfo.Column("blockNumber", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20Event.put("contractAddress", TableInfo.Column("contractAddress", "BLOB", true,
            2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20Event.put("from", TableInfo.Column("from", "BLOB", true, 3, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20Event.put("to", TableInfo.Column("to", "BLOB", true, 4, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20Event.put("value", TableInfo.Column("value", "TEXT", true, 5, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20Event.put("tokenName", TableInfo.Column("tokenName", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20Event.put("tokenSymbol", TableInfo.Column("tokenSymbol", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20Event.put("tokenDecimal", TableInfo.Column("tokenDecimal", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysEip20Event: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesEip20Event: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoEip20Event: TableInfo = TableInfo("Eip20Event", _columnsEip20Event,
            _foreignKeysEip20Event, _indicesEip20Event)
        val _existingEip20Event: TableInfo = read(connection, "Eip20Event")
        if (!_infoEip20Event.equals(_existingEip20Event)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |Eip20Event(io.horizontalsystems.ethereumkit.models.Eip20Event).
              | Expected:
              |""".trimMargin() + _infoEip20Event + """
              |
              | Found:
              |""".trimMargin() + _existingEip20Event)
        }
        val _columnsEip20SyncState: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsEip20SyncState.put("contractAddress", TableInfo.Column("contractAddress", "TEXT",
            true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20SyncState.put("lastScannedBlock", TableInfo.Column("lastScannedBlock",
            "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip20SyncState.put("historicalMinScannedBlock",
            TableInfo.Column("historicalMinScannedBlock", "INTEGER", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysEip20SyncState: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesEip20SyncState: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoEip20SyncState: TableInfo = TableInfo("Eip20SyncState", _columnsEip20SyncState,
            _foreignKeysEip20SyncState, _indicesEip20SyncState)
        val _existingEip20SyncState: TableInfo = read(connection, "Eip20SyncState")
        if (!_infoEip20SyncState.equals(_existingEip20SyncState)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |Eip20SyncState(io.horizontalsystems.ethereumkit.models.Eip20SyncState).
              | Expected:
              |""".trimMargin() + _infoEip20SyncState + """
              |
              | Found:
              |""".trimMargin() + _existingEip20SyncState)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "Eip20Event", "Eip20SyncState")
  }

  public override fun clearAllTables() {
    super.performClear(false, "Eip20Event", "Eip20SyncState")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(Eip20EventDao::class, Eip20EventDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(Eip20SyncStateDao::class, Eip20SyncStateDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun eip20EventDao(): Eip20EventDao = _eip20EventDao.value

  public override fun eip20SyncStateDao(): Eip20SyncStateDao = _eip20SyncStateDao.value
}
