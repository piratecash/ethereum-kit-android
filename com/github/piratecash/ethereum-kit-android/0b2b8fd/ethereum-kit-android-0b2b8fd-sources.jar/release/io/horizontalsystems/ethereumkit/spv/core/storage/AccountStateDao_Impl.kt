package io.horizontalsystems.ethereumkit.spv.core.storage

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.api.storage.RoomTypeConverters
import io.horizontalsystems.ethereumkit.models.Address
import io.horizontalsystems.ethereumkit.spv.models.AccountStateSpv
import java.math.BigInteger
import javax.`annotation`.processing.Generated
import kotlin.ByteArray
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class AccountStateDao_Impl(
  __db: RoomDatabase,
) : AccountStateDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfAccountStateSpv: EntityInsertAdapter<AccountStateSpv>

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()
  init {
    this.__db = __db
    this.__insertAdapterOfAccountStateSpv = object : EntityInsertAdapter<AccountStateSpv>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `AccountStateSpv` (`address`,`nonce`,`balance`,`storageHash`,`codeHash`) VALUES (?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: AccountStateSpv) {
        val _tmp: ByteArray? = __roomTypeConverters.addressToByteArray(entity.address)
        if (_tmp == null) {
          statement.bindNull(1)
        } else {
          statement.bindBlob(1, _tmp)
        }
        statement.bindLong(2, entity.nonce)
        val _tmp_1: String? = __roomTypeConverters.bigIntegerToString(entity.balance)
        if (_tmp_1 == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmp_1)
        }
        statement.bindBlob(4, entity.storageHash)
        statement.bindBlob(5, entity.codeHash)
      }
    }
  }

  public override fun insert(accountState: AccountStateSpv): Unit = performBlocking(__db, false,
      true) { _connection ->
    __insertAdapterOfAccountStateSpv.insert(_connection, accountState)
  }

  public override fun getAccountState(): AccountStateSpv? {
    val _sql: String = "SELECT * FROM AccountStateSpv LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfAddress: Int = getColumnIndexOrThrow(_stmt, "address")
        val _columnIndexOfNonce: Int = getColumnIndexOrThrow(_stmt, "nonce")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfStorageHash: Int = getColumnIndexOrThrow(_stmt, "storageHash")
        val _columnIndexOfCodeHash: Int = getColumnIndexOrThrow(_stmt, "codeHash")
        val _result: AccountStateSpv?
        if (_stmt.step()) {
          val _tmpAddress: Address
          val _tmp: ByteArray?
          if (_stmt.isNull(_columnIndexOfAddress)) {
            _tmp = null
          } else {
            _tmp = _stmt.getBlob(_columnIndexOfAddress)
          }
          val _tmp_1: Address? = __roomTypeConverters.addressFromByteArray(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpAddress = _tmp_1
          }
          val _tmpNonce: Long
          _tmpNonce = _stmt.getLong(_columnIndexOfNonce)
          val _tmpBalance: BigInteger
          val _tmp_2: String?
          if (_stmt.isNull(_columnIndexOfBalance)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getText(_columnIndexOfBalance)
          }
          val _tmp_3: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_2)
          if (_tmp_3 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpBalance = _tmp_3
          }
          val _tmpStorageHash: ByteArray
          _tmpStorageHash = _stmt.getBlob(_columnIndexOfStorageHash)
          val _tmpCodeHash: ByteArray
          _tmpCodeHash = _stmt.getBlob(_columnIndexOfCodeHash)
          _result = AccountStateSpv(_tmpAddress,_tmpNonce,_tmpBalance,_tmpStorageHash,_tmpCodeHash)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
