package io.horizontalsystems.ethereumkit.core.storage

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TransactionDatabase_Impl : TransactionDatabase() {
  private val _transactionDao: Lazy<TransactionDao> = lazy {
    TransactionDao_Impl(this)
  }

  private val _transactionTagDao: Lazy<TransactionTagDao> = lazy {
    TransactionTagDao_Impl(this)
  }

  private val _transactionSyncerStateDao: Lazy<TransactionSyncerStateDao> = lazy {
    TransactionSyncerStateDao_Impl(this)
  }

  private val _transactionSyncSourceDao: Lazy<TransactionSyncSourceDao> = lazy {
    TransactionSyncSourceDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(15,
        "66f26b2a29740e1691f81ee4efd603c4", "c9890bd0d79376a8425ade3add5043ef") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `Transaction` (`hash` BLOB NOT NULL, `timestamp` INTEGER NOT NULL, `isFailed` INTEGER NOT NULL, `blockNumber` INTEGER, `transactionIndex` INTEGER, `from` BLOB, `to` BLOB, `value` TEXT, `input` BLOB, `nonce` INTEGER, `gasPrice` INTEGER, `maxFeePerGas` INTEGER, `maxPriorityFeePerGas` INTEGER, `gasLimit` INTEGER, `gasUsed` INTEGER, `replacedWith` BLOB, PRIMARY KEY(`hash`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `InternalTransaction` (`hash` BLOB NOT NULL, `traceId` TEXT NOT NULL, `blockNumber` INTEGER NOT NULL, `from` BLOB NOT NULL, `to` BLOB NOT NULL, `value` TEXT NOT NULL, PRIMARY KEY(`hash`, `traceId`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `TransactionTag` (`name` TEXT NOT NULL, `hash` BLOB NOT NULL, PRIMARY KEY(`name`, `hash`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `TransactionSyncerState` (`syncerId` TEXT NOT NULL, `lastBlockNumber` INTEGER NOT NULL, PRIMARY KEY(`syncerId`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `TransactionSyncSource` (`transactionHash` BLOB NOT NULL, `source` TEXT NOT NULL, PRIMARY KEY(`transactionHash`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '66f26b2a29740e1691f81ee4efd603c4')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `Transaction`")
        connection.execSQL("DROP TABLE IF EXISTS `InternalTransaction`")
        connection.execSQL("DROP TABLE IF EXISTS `TransactionTag`")
        connection.execSQL("DROP TABLE IF EXISTS `TransactionSyncerState`")
        connection.execSQL("DROP TABLE IF EXISTS `TransactionSyncSource`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsTransaction: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTransaction.put("hash", TableInfo.Column("hash", "BLOB", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("timestamp", TableInfo.Column("timestamp", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("isFailed", TableInfo.Column("isFailed", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("blockNumber", TableInfo.Column("blockNumber", "INTEGER", false, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("transactionIndex", TableInfo.Column("transactionIndex", "INTEGER",
            false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("from", TableInfo.Column("from", "BLOB", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("to", TableInfo.Column("to", "BLOB", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("value", TableInfo.Column("value", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("input", TableInfo.Column("input", "BLOB", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("nonce", TableInfo.Column("nonce", "INTEGER", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("gasPrice", TableInfo.Column("gasPrice", "INTEGER", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("maxFeePerGas", TableInfo.Column("maxFeePerGas", "INTEGER", false,
            0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("maxPriorityFeePerGas", TableInfo.Column("maxPriorityFeePerGas",
            "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("gasLimit", TableInfo.Column("gasLimit", "INTEGER", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("gasUsed", TableInfo.Column("gasUsed", "INTEGER", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("replacedWith", TableInfo.Column("replacedWith", "BLOB", false, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTransaction: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesTransaction: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoTransaction: TableInfo = TableInfo("Transaction", _columnsTransaction,
            _foreignKeysTransaction, _indicesTransaction)
        val _existingTransaction: TableInfo = read(connection, "Transaction")
        if (!_infoTransaction.equals(_existingTransaction)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |Transaction(io.horizontalsystems.ethereumkit.models.Transaction).
              | Expected:
              |""".trimMargin() + _infoTransaction + """
              |
              | Found:
              |""".trimMargin() + _existingTransaction)
        }
        val _columnsInternalTransaction: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsInternalTransaction.put("hash", TableInfo.Column("hash", "BLOB", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsInternalTransaction.put("traceId", TableInfo.Column("traceId", "TEXT", true, 2,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsInternalTransaction.put("blockNumber", TableInfo.Column("blockNumber", "INTEGER",
            true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsInternalTransaction.put("from", TableInfo.Column("from", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsInternalTransaction.put("to", TableInfo.Column("to", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsInternalTransaction.put("value", TableInfo.Column("value", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysInternalTransaction: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesInternalTransaction: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoInternalTransaction: TableInfo = TableInfo("InternalTransaction",
            _columnsInternalTransaction, _foreignKeysInternalTransaction,
            _indicesInternalTransaction)
        val _existingInternalTransaction: TableInfo = read(connection, "InternalTransaction")
        if (!_infoInternalTransaction.equals(_existingInternalTransaction)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |InternalTransaction(io.horizontalsystems.ethereumkit.models.InternalTransaction).
              | Expected:
              |""".trimMargin() + _infoInternalTransaction + """
              |
              | Found:
              |""".trimMargin() + _existingInternalTransaction)
        }
        val _columnsTransactionTag: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTransactionTag.put("name", TableInfo.Column("name", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransactionTag.put("hash", TableInfo.Column("hash", "BLOB", true, 2, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTransactionTag: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesTransactionTag: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoTransactionTag: TableInfo = TableInfo("TransactionTag", _columnsTransactionTag,
            _foreignKeysTransactionTag, _indicesTransactionTag)
        val _existingTransactionTag: TableInfo = read(connection, "TransactionTag")
        if (!_infoTransactionTag.equals(_existingTransactionTag)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |TransactionTag(io.horizontalsystems.ethereumkit.models.TransactionTag).
              | Expected:
              |""".trimMargin() + _infoTransactionTag + """
              |
              | Found:
              |""".trimMargin() + _existingTransactionTag)
        }
        val _columnsTransactionSyncerState: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTransactionSyncerState.put("syncerId", TableInfo.Column("syncerId", "TEXT", true, 1,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTransactionSyncerState.put("lastBlockNumber", TableInfo.Column("lastBlockNumber",
            "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTransactionSyncerState: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesTransactionSyncerState: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoTransactionSyncerState: TableInfo = TableInfo("TransactionSyncerState",
            _columnsTransactionSyncerState, _foreignKeysTransactionSyncerState,
            _indicesTransactionSyncerState)
        val _existingTransactionSyncerState: TableInfo = read(connection, "TransactionSyncerState")
        if (!_infoTransactionSyncerState.equals(_existingTransactionSyncerState)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |TransactionSyncerState(io.horizontalsystems.ethereumkit.models.TransactionSyncerState).
              | Expected:
              |""".trimMargin() + _infoTransactionSyncerState + """
              |
              | Found:
              |""".trimMargin() + _existingTransactionSyncerState)
        }
        val _columnsTransactionSyncSource: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTransactionSyncSource.put("transactionHash", TableInfo.Column("transactionHash",
            "BLOB", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTransactionSyncSource.put("source", TableInfo.Column("source", "TEXT", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTransactionSyncSource: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesTransactionSyncSource: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoTransactionSyncSource: TableInfo = TableInfo("TransactionSyncSource",
            _columnsTransactionSyncSource, _foreignKeysTransactionSyncSource,
            _indicesTransactionSyncSource)
        val _existingTransactionSyncSource: TableInfo = read(connection, "TransactionSyncSource")
        if (!_infoTransactionSyncSource.equals(_existingTransactionSyncSource)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |TransactionSyncSource(io.horizontalsystems.ethereumkit.models.TransactionSyncSource).
              | Expected:
              |""".trimMargin() + _infoTransactionSyncSource + """
              |
              | Found:
              |""".trimMargin() + _existingTransactionSyncSource)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "Transaction",
        "InternalTransaction", "TransactionTag", "TransactionSyncerState", "TransactionSyncSource")
  }

  public override fun clearAllTables() {
    super.performClear(false, "Transaction", "InternalTransaction", "TransactionTag",
        "TransactionSyncerState", "TransactionSyncSource")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(TransactionDao::class, TransactionDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(TransactionTagDao::class, TransactionTagDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(TransactionSyncerStateDao::class,
        TransactionSyncerStateDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(TransactionSyncSourceDao::class,
        TransactionSyncSourceDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun transactionDao(): TransactionDao = _transactionDao.value

  public override fun transactionTagDao(): TransactionTagDao = _transactionTagDao.value

  public override fun transactionSyncerStateDao(): TransactionSyncerStateDao =
      _transactionSyncerStateDao.value

  public override fun transactionSyncSourceDao(): TransactionSyncSourceDao =
      _transactionSyncSourceDao.value
}
