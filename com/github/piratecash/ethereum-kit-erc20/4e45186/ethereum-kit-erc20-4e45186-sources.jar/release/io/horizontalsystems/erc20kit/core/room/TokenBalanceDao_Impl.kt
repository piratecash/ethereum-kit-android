package io.horizontalsystems.erc20kit.core.room

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.erc20kit.models.TokenBalance
import io.horizontalsystems.ethereumkit.api.storage.RoomTypeConverters
import java.math.BigInteger
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TokenBalanceDao_Impl(
  __db: RoomDatabase,
) : TokenBalanceDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTokenBalance: EntityInsertAdapter<TokenBalance>

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()
  init {
    this.__db = __db
    this.__insertAdapterOfTokenBalance = object : EntityInsertAdapter<TokenBalance>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `TokenBalance` (`value`,`primaryKey`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TokenBalance) {
        val _tmp: String? = __roomTypeConverters.bigIntegerToString(entity.value)
        if (_tmp == null) {
          statement.bindNull(1)
        } else {
          statement.bindText(1, _tmp)
        }
        statement.bindText(2, entity.primaryKey)
      }
    }
  }

  public override fun insert(balance: TokenBalance): Unit = performBlocking(__db, false, true) {
      _connection ->
    __insertAdapterOfTokenBalance.insert(_connection, balance)
  }

  public override fun getBalance(): TokenBalance? {
    val _sql: String = "SELECT * FROM TokenBalance LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfPrimaryKey: Int = getColumnIndexOrThrow(_stmt, "primaryKey")
        val _result: TokenBalance?
        if (_stmt.step()) {
          val _tmpValue: BigInteger
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfValue)
          }
          val _tmp_1: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpValue = _tmp_1
          }
          val _tmpPrimaryKey: String
          _tmpPrimaryKey = _stmt.getText(_columnIndexOfPrimaryKey)
          _result = TokenBalance(_tmpValue,_tmpPrimaryKey)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
