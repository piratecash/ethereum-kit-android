package io.horizontalsystems.erc20kit.core.room

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class Erc20KitDatabase_Impl : Erc20KitDatabase() {
  private val _tokenBalanceDao: Lazy<TokenBalanceDao> = lazy {
    TokenBalanceDao_Impl(this)
  }

  public override val tokenBalanceDao: TokenBalanceDao
    get() = _tokenBalanceDao.value

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(5,
        "b41fd03f17eba452b3eb9b433cb02e29", "73c83a43a8400f1dc74586b8c4618ed9") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `TokenBalance` (`value` TEXT NOT NULL, `primaryKey` TEXT NOT NULL, PRIMARY KEY(`primaryKey`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'b41fd03f17eba452b3eb9b433cb02e29')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `TokenBalance`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsTokenBalance: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTokenBalance.put("value", TableInfo.Column("value", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTokenBalance.put("primaryKey", TableInfo.Column("primaryKey", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTokenBalance: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesTokenBalance: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoTokenBalance: TableInfo = TableInfo("TokenBalance", _columnsTokenBalance,
            _foreignKeysTokenBalance, _indicesTokenBalance)
        val _existingTokenBalance: TableInfo = read(connection, "TokenBalance")
        if (!_infoTokenBalance.equals(_existingTokenBalance)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |TokenBalance(io.horizontalsystems.erc20kit.models.TokenBalance).
              | Expected:
              |""".trimMargin() + _infoTokenBalance + """
              |
              | Found:
              |""".trimMargin() + _existingTokenBalance)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "TokenBalance")
  }

  public override fun clearAllTables() {
    super.performClear(false, "TokenBalance")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(TokenBalanceDao::class, TokenBalanceDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }
}
