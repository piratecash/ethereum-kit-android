package io.horizontalsystems.nftkit.core.db

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.api.storage.RoomTypeConverters
import io.horizontalsystems.ethereumkit.models.Address
import io.horizontalsystems.nftkit.models.Eip721Event
import java.math.BigInteger
import javax.`annotation`.processing.Generated
import kotlin.ByteArray
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class Eip721EventDao_Impl(
  __db: RoomDatabase,
) : Eip721EventDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfEip721Event: EntityInsertAdapter<Eip721Event>

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()
  init {
    this.__db = __db
    this.__insertAdapterOfEip721Event = object : EntityInsertAdapter<Eip721Event>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `Eip721Event` (`hash`,`blockNumber`,`contractAddress`,`from`,`to`,`tokenId`,`tokenName`,`tokenSymbol`,`tokenDecimal`,`id`) VALUES (?,?,?,?,?,?,?,?,?,nullif(?, 0))"

      protected override fun bind(statement: SQLiteStatement, entity: Eip721Event) {
        statement.bindBlob(1, entity.hash)
        statement.bindLong(2, entity.blockNumber)
        val _tmp: ByteArray? = __roomTypeConverters.addressToByteArray(entity.contractAddress)
        if (_tmp == null) {
          statement.bindNull(3)
        } else {
          statement.bindBlob(3, _tmp)
        }
        val _tmp_1: ByteArray? = __roomTypeConverters.addressToByteArray(entity.from)
        if (_tmp_1 == null) {
          statement.bindNull(4)
        } else {
          statement.bindBlob(4, _tmp_1)
        }
        val _tmp_2: ByteArray? = __roomTypeConverters.addressToByteArray(entity.to)
        if (_tmp_2 == null) {
          statement.bindNull(5)
        } else {
          statement.bindBlob(5, _tmp_2)
        }
        val _tmp_3: String? = __roomTypeConverters.bigIntegerToString(entity.tokenId)
        if (_tmp_3 == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmp_3)
        }
        statement.bindText(7, entity.tokenName)
        statement.bindText(8, entity.tokenSymbol)
        statement.bindLong(9, entity.tokenDecimal.toLong())
        statement.bindLong(10, entity.id)
      }
    }
  }

  public override fun insertAll(list: List<Eip721Event>): Unit = performBlocking(__db, false, true)
      { _connection ->
    __insertAdapterOfEip721Event.insert(_connection, list)
  }

  public override fun lastEvent(): Eip721Event? {
    val _sql: String = "SELECT * FROM Eip721Event ORDER BY blockNumber DESC LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfContractAddress: Int = getColumnIndexOrThrow(_stmt, "contractAddress")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfTokenId: Int = getColumnIndexOrThrow(_stmt, "tokenId")
        val _columnIndexOfTokenName: Int = getColumnIndexOrThrow(_stmt, "tokenName")
        val _columnIndexOfTokenSymbol: Int = getColumnIndexOrThrow(_stmt, "tokenSymbol")
        val _columnIndexOfTokenDecimal: Int = getColumnIndexOrThrow(_stmt, "tokenDecimal")
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _result: Eip721Event?
        if (_stmt.step()) {
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpBlockNumber: Long
          _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          val _tmpContractAddress: Address
          val _tmp: ByteArray?
          if (_stmt.isNull(_columnIndexOfContractAddress)) {
            _tmp = null
          } else {
            _tmp = _stmt.getBlob(_columnIndexOfContractAddress)
          }
          val _tmp_1: Address? = __roomTypeConverters.addressFromByteArray(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpContractAddress = _tmp_1
          }
          val _tmpFrom: Address
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfFrom)
          }
          val _tmp_3: Address? = __roomTypeConverters.addressFromByteArray(_tmp_2)
          if (_tmp_3 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpFrom = _tmp_3
          }
          val _tmpTo: Address
          val _tmp_4: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getBlob(_columnIndexOfTo)
          }
          val _tmp_5: Address? = __roomTypeConverters.addressFromByteArray(_tmp_4)
          if (_tmp_5 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpTo = _tmp_5
          }
          val _tmpTokenId: BigInteger
          val _tmp_6: String?
          if (_stmt.isNull(_columnIndexOfTokenId)) {
            _tmp_6 = null
          } else {
            _tmp_6 = _stmt.getText(_columnIndexOfTokenId)
          }
          val _tmp_7: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_6)
          if (_tmp_7 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTokenId = _tmp_7
          }
          val _tmpTokenName: String
          _tmpTokenName = _stmt.getText(_columnIndexOfTokenName)
          val _tmpTokenSymbol: String
          _tmpTokenSymbol = _stmt.getText(_columnIndexOfTokenSymbol)
          val _tmpTokenDecimal: Int
          _tmpTokenDecimal = _stmt.getLong(_columnIndexOfTokenDecimal).toInt()
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          _result =
              Eip721Event(_tmpHash,_tmpBlockNumber,_tmpContractAddress,_tmpFrom,_tmpTo,_tmpTokenId,_tmpTokenName,_tmpTokenSymbol,_tmpTokenDecimal,_tmpId)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun events(): List<Eip721Event> {
    val _sql: String = "SELECT * FROM Eip721Event"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfContractAddress: Int = getColumnIndexOrThrow(_stmt, "contractAddress")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfTokenId: Int = getColumnIndexOrThrow(_stmt, "tokenId")
        val _columnIndexOfTokenName: Int = getColumnIndexOrThrow(_stmt, "tokenName")
        val _columnIndexOfTokenSymbol: Int = getColumnIndexOrThrow(_stmt, "tokenSymbol")
        val _columnIndexOfTokenDecimal: Int = getColumnIndexOrThrow(_stmt, "tokenDecimal")
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _result: MutableList<Eip721Event> = mutableListOf()
        while (_stmt.step()) {
          val _item: Eip721Event
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpBlockNumber: Long
          _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          val _tmpContractAddress: Address
          val _tmp: ByteArray?
          if (_stmt.isNull(_columnIndexOfContractAddress)) {
            _tmp = null
          } else {
            _tmp = _stmt.getBlob(_columnIndexOfContractAddress)
          }
          val _tmp_1: Address? = __roomTypeConverters.addressFromByteArray(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpContractAddress = _tmp_1
          }
          val _tmpFrom: Address
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfFrom)
          }
          val _tmp_3: Address? = __roomTypeConverters.addressFromByteArray(_tmp_2)
          if (_tmp_3 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpFrom = _tmp_3
          }
          val _tmpTo: Address
          val _tmp_4: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getBlob(_columnIndexOfTo)
          }
          val _tmp_5: Address? = __roomTypeConverters.addressFromByteArray(_tmp_4)
          if (_tmp_5 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpTo = _tmp_5
          }
          val _tmpTokenId: BigInteger
          val _tmp_6: String?
          if (_stmt.isNull(_columnIndexOfTokenId)) {
            _tmp_6 = null
          } else {
            _tmp_6 = _stmt.getText(_columnIndexOfTokenId)
          }
          val _tmp_7: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_6)
          if (_tmp_7 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTokenId = _tmp_7
          }
          val _tmpTokenName: String
          _tmpTokenName = _stmt.getText(_columnIndexOfTokenName)
          val _tmpTokenSymbol: String
          _tmpTokenSymbol = _stmt.getText(_columnIndexOfTokenSymbol)
          val _tmpTokenDecimal: Int
          _tmpTokenDecimal = _stmt.getLong(_columnIndexOfTokenDecimal).toInt()
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          _item =
              Eip721Event(_tmpHash,_tmpBlockNumber,_tmpContractAddress,_tmpFrom,_tmpTo,_tmpTokenId,_tmpTokenName,_tmpTokenSymbol,_tmpTokenDecimal,_tmpId)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun eventsByHash(hashes: List<ByteArray>): List<Eip721Event> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM Eip721Event WHERE hash IN (")
    val _inputSize: Int = hashes.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: ByteArray in hashes) {
          _stmt.bindBlob(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfBlockNumber: Int = getColumnIndexOrThrow(_stmt, "blockNumber")
        val _columnIndexOfContractAddress: Int = getColumnIndexOrThrow(_stmt, "contractAddress")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfTokenId: Int = getColumnIndexOrThrow(_stmt, "tokenId")
        val _columnIndexOfTokenName: Int = getColumnIndexOrThrow(_stmt, "tokenName")
        val _columnIndexOfTokenSymbol: Int = getColumnIndexOrThrow(_stmt, "tokenSymbol")
        val _columnIndexOfTokenDecimal: Int = getColumnIndexOrThrow(_stmt, "tokenDecimal")
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _result: MutableList<Eip721Event> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: Eip721Event
          val _tmpHash: ByteArray
          _tmpHash = _stmt.getBlob(_columnIndexOfHash)
          val _tmpBlockNumber: Long
          _tmpBlockNumber = _stmt.getLong(_columnIndexOfBlockNumber)
          val _tmpContractAddress: Address
          val _tmp: ByteArray?
          if (_stmt.isNull(_columnIndexOfContractAddress)) {
            _tmp = null
          } else {
            _tmp = _stmt.getBlob(_columnIndexOfContractAddress)
          }
          val _tmp_1: Address? = __roomTypeConverters.addressFromByteArray(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpContractAddress = _tmp_1
          }
          val _tmpFrom: Address
          val _tmp_2: ByteArray?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getBlob(_columnIndexOfFrom)
          }
          val _tmp_3: Address? = __roomTypeConverters.addressFromByteArray(_tmp_2)
          if (_tmp_3 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpFrom = _tmp_3
          }
          val _tmpTo: Address
          val _tmp_4: ByteArray?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getBlob(_columnIndexOfTo)
          }
          val _tmp_5: Address? = __roomTypeConverters.addressFromByteArray(_tmp_4)
          if (_tmp_5 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpTo = _tmp_5
          }
          val _tmpTokenId: BigInteger
          val _tmp_6: String?
          if (_stmt.isNull(_columnIndexOfTokenId)) {
            _tmp_6 = null
          } else {
            _tmp_6 = _stmt.getText(_columnIndexOfTokenId)
          }
          val _tmp_7: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_6)
          if (_tmp_7 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTokenId = _tmp_7
          }
          val _tmpTokenName: String
          _tmpTokenName = _stmt.getText(_columnIndexOfTokenName)
          val _tmpTokenSymbol: String
          _tmpTokenSymbol = _stmt.getText(_columnIndexOfTokenSymbol)
          val _tmpTokenDecimal: Int
          _tmpTokenDecimal = _stmt.getLong(_columnIndexOfTokenDecimal).toInt()
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          _item_1 =
              Eip721Event(_tmpHash,_tmpBlockNumber,_tmpContractAddress,_tmpFrom,_tmpTo,_tmpTokenId,_tmpTokenName,_tmpTokenSymbol,_tmpTokenDecimal,_tmpId)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
