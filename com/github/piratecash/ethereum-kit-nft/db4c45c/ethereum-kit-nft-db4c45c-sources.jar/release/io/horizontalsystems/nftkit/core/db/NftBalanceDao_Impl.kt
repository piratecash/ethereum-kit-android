package io.horizontalsystems.nftkit.core.db

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.ethereumkit.api.storage.RoomTypeConverters
import io.horizontalsystems.ethereumkit.models.Address
import io.horizontalsystems.nftkit.models.Nft
import io.horizontalsystems.nftkit.models.NftBalance
import io.horizontalsystems.nftkit.models.NftBalanceRecord
import io.horizontalsystems.nftkit.models.NftType
import java.math.BigInteger
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.ByteArray
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class NftBalanceDao_Impl(
  __db: RoomDatabase,
) : NftBalanceDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfNftBalanceRecord: EntityInsertAdapter<NftBalanceRecord>

  private val __nftTypeConverters: NftTypeConverters = NftTypeConverters()

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()
  init {
    this.__db = __db
    this.__insertAdapterOfNftBalanceRecord = object : EntityInsertAdapter<NftBalanceRecord>() {
      protected override fun createQuery(): String =
          "INSERT OR ABORT INTO `NftBalanceRecord` (`type`,`contractAddress`,`tokenId`,`tokenName`,`balance`,`synced`) VALUES (?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: NftBalanceRecord) {
        val _tmp: String? = __nftTypeConverters.nftTypeToString(entity.type)
        if (_tmp == null) {
          statement.bindNull(1)
        } else {
          statement.bindText(1, _tmp)
        }
        val _tmp_1: ByteArray? = __roomTypeConverters.addressToByteArray(entity.contractAddress)
        if (_tmp_1 == null) {
          statement.bindNull(2)
        } else {
          statement.bindBlob(2, _tmp_1)
        }
        val _tmp_2: String? = __roomTypeConverters.bigIntegerToString(entity.tokenId)
        if (_tmp_2 == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmp_2)
        }
        statement.bindText(4, entity.tokenName)
        statement.bindLong(5, entity.balance.toLong())
        val _tmp_3: Int = if (entity.synced) 1 else 0
        statement.bindLong(6, _tmp_3.toLong())
      }
    }
  }

  public override fun insertAll(balances: List<NftBalanceRecord>): Unit = performBlocking(__db,
      false, true) { _connection ->
    __insertAdapterOfNftBalanceRecord.insert(_connection, balances)
  }

  public override fun nftBalances(type: NftType): List<NftBalance> {
    val _sql: String = "SELECT * FROM NftBalanceRecord WHERE type = ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: String? = __nftTypeConverters.nftTypeToString(type)
        if (_tmp == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, _tmp)
        }
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfContractAddress: Int = getColumnIndexOrThrow(_stmt, "contractAddress")
        val _columnIndexOfTokenId: Int = getColumnIndexOrThrow(_stmt, "tokenId")
        val _columnIndexOfTokenName: Int = getColumnIndexOrThrow(_stmt, "tokenName")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfSynced: Int = getColumnIndexOrThrow(_stmt, "synced")
        val _result: MutableList<NftBalance> = mutableListOf()
        while (_stmt.step()) {
          val _item: NftBalance
          val _tmpBalance: Int
          _tmpBalance = _stmt.getLong(_columnIndexOfBalance).toInt()
          val _tmpSynced: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfSynced).toInt()
          _tmpSynced = _tmp_1 != 0
          val _tmpNft: Nft
          val _tmpType: NftType
          val _tmp_2: String?
          if (_stmt.isNull(_columnIndexOfType)) {
            _tmp_2 = null
          } else {
            _tmp_2 = _stmt.getText(_columnIndexOfType)
          }
          val _tmp_3: NftType? = __nftTypeConverters.nftTypeFromString(_tmp_2)
          if (_tmp_3 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.nftkit.models.NftType', but it was NULL.")
          } else {
            _tmpType = _tmp_3
          }
          val _tmpContractAddress: Address
          val _tmp_4: ByteArray?
          if (_stmt.isNull(_columnIndexOfContractAddress)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getBlob(_columnIndexOfContractAddress)
          }
          val _tmp_5: Address? = __roomTypeConverters.addressFromByteArray(_tmp_4)
          if (_tmp_5 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpContractAddress = _tmp_5
          }
          val _tmpTokenId: BigInteger
          val _tmp_6: String?
          if (_stmt.isNull(_columnIndexOfTokenId)) {
            _tmp_6 = null
          } else {
            _tmp_6 = _stmt.getText(_columnIndexOfTokenId)
          }
          val _tmp_7: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_6)
          if (_tmp_7 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTokenId = _tmp_7
          }
          val _tmpTokenName: String
          _tmpTokenName = _stmt.getText(_columnIndexOfTokenName)
          _tmpNft = Nft(_tmpType,_tmpContractAddress,_tmpTokenId,_tmpTokenName)
          _item = NftBalance(_tmpNft,_tmpBalance,_tmpSynced)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun existingNftBalances(): List<NftBalance> {
    val _sql: String = "SELECT * FROM NftBalanceRecord WHERE balance > 0"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfContractAddress: Int = getColumnIndexOrThrow(_stmt, "contractAddress")
        val _columnIndexOfTokenId: Int = getColumnIndexOrThrow(_stmt, "tokenId")
        val _columnIndexOfTokenName: Int = getColumnIndexOrThrow(_stmt, "tokenName")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfSynced: Int = getColumnIndexOrThrow(_stmt, "synced")
        val _result: MutableList<NftBalance> = mutableListOf()
        while (_stmt.step()) {
          val _item: NftBalance
          val _tmpBalance: Int
          _tmpBalance = _stmt.getLong(_columnIndexOfBalance).toInt()
          val _tmpSynced: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfSynced).toInt()
          _tmpSynced = _tmp != 0
          val _tmpNft: Nft
          val _tmpType: NftType
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfType)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfType)
          }
          val _tmp_2: NftType? = __nftTypeConverters.nftTypeFromString(_tmp_1)
          if (_tmp_2 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.nftkit.models.NftType', but it was NULL.")
          } else {
            _tmpType = _tmp_2
          }
          val _tmpContractAddress: Address
          val _tmp_3: ByteArray?
          if (_stmt.isNull(_columnIndexOfContractAddress)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getBlob(_columnIndexOfContractAddress)
          }
          val _tmp_4: Address? = __roomTypeConverters.addressFromByteArray(_tmp_3)
          if (_tmp_4 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpContractAddress = _tmp_4
          }
          val _tmpTokenId: BigInteger
          val _tmp_5: String?
          if (_stmt.isNull(_columnIndexOfTokenId)) {
            _tmp_5 = null
          } else {
            _tmp_5 = _stmt.getText(_columnIndexOfTokenId)
          }
          val _tmp_6: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_5)
          if (_tmp_6 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTokenId = _tmp_6
          }
          val _tmpTokenName: String
          _tmpTokenName = _stmt.getText(_columnIndexOfTokenName)
          _tmpNft = Nft(_tmpType,_tmpContractAddress,_tmpTokenId,_tmpTokenName)
          _item = NftBalance(_tmpNft,_tmpBalance,_tmpSynced)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun nonSyncedNftBalances(): List<NftBalance> {
    val _sql: String = "SELECT * FROM NftBalanceRecord WHERE synced = 0"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfContractAddress: Int = getColumnIndexOrThrow(_stmt, "contractAddress")
        val _columnIndexOfTokenId: Int = getColumnIndexOrThrow(_stmt, "tokenId")
        val _columnIndexOfTokenName: Int = getColumnIndexOrThrow(_stmt, "tokenName")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfSynced: Int = getColumnIndexOrThrow(_stmt, "synced")
        val _result: MutableList<NftBalance> = mutableListOf()
        while (_stmt.step()) {
          val _item: NftBalance
          val _tmpBalance: Int
          _tmpBalance = _stmt.getLong(_columnIndexOfBalance).toInt()
          val _tmpSynced: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfSynced).toInt()
          _tmpSynced = _tmp != 0
          val _tmpNft: Nft
          val _tmpType: NftType
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfType)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfType)
          }
          val _tmp_2: NftType? = __nftTypeConverters.nftTypeFromString(_tmp_1)
          if (_tmp_2 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.nftkit.models.NftType', but it was NULL.")
          } else {
            _tmpType = _tmp_2
          }
          val _tmpContractAddress: Address
          val _tmp_3: ByteArray?
          if (_stmt.isNull(_columnIndexOfContractAddress)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getBlob(_columnIndexOfContractAddress)
          }
          val _tmp_4: Address? = __roomTypeConverters.addressFromByteArray(_tmp_3)
          if (_tmp_4 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpContractAddress = _tmp_4
          }
          val _tmpTokenId: BigInteger
          val _tmp_5: String?
          if (_stmt.isNull(_columnIndexOfTokenId)) {
            _tmp_5 = null
          } else {
            _tmp_5 = _stmt.getText(_columnIndexOfTokenId)
          }
          val _tmp_6: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_5)
          if (_tmp_6 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTokenId = _tmp_6
          }
          val _tmpTokenName: String
          _tmpTokenName = _stmt.getText(_columnIndexOfTokenName)
          _tmpNft = Nft(_tmpType,_tmpContractAddress,_tmpTokenId,_tmpTokenName)
          _item = NftBalance(_tmpNft,_tmpBalance,_tmpSynced)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun existingNftBalance(contractAddress: Address, tokenId: BigInteger):
      NftBalance? {
    val _sql: String =
        "SELECT * FROM NftBalanceRecord WHERE contractAddress = ? AND tokenId = ? AND balance > 0"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: ByteArray? = __roomTypeConverters.addressToByteArray(contractAddress)
        if (_tmp == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindBlob(_argIndex, _tmp)
        }
        _argIndex = 2
        val _tmp_1: String? = __roomTypeConverters.bigIntegerToString(tokenId)
        if (_tmp_1 == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, _tmp_1)
        }
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfContractAddress: Int = getColumnIndexOrThrow(_stmt, "contractAddress")
        val _columnIndexOfTokenId: Int = getColumnIndexOrThrow(_stmt, "tokenId")
        val _columnIndexOfTokenName: Int = getColumnIndexOrThrow(_stmt, "tokenName")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfSynced: Int = getColumnIndexOrThrow(_stmt, "synced")
        val _result: NftBalance?
        if (_stmt.step()) {
          val _tmpBalance: Int
          _tmpBalance = _stmt.getLong(_columnIndexOfBalance).toInt()
          val _tmpSynced: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfSynced).toInt()
          _tmpSynced = _tmp_2 != 0
          val _tmpNft: Nft
          val _tmpType: NftType
          val _tmp_3: String?
          if (_stmt.isNull(_columnIndexOfType)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getText(_columnIndexOfType)
          }
          val _tmp_4: NftType? = __nftTypeConverters.nftTypeFromString(_tmp_3)
          if (_tmp_4 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.nftkit.models.NftType', but it was NULL.")
          } else {
            _tmpType = _tmp_4
          }
          val _tmpContractAddress: Address
          val _tmp_5: ByteArray?
          if (_stmt.isNull(_columnIndexOfContractAddress)) {
            _tmp_5 = null
          } else {
            _tmp_5 = _stmt.getBlob(_columnIndexOfContractAddress)
          }
          val _tmp_6: Address? = __roomTypeConverters.addressFromByteArray(_tmp_5)
          if (_tmp_6 == null) {
            error("Expected NON-NULL 'io.horizontalsystems.ethereumkit.models.Address', but it was NULL.")
          } else {
            _tmpContractAddress = _tmp_6
          }
          val _tmpTokenId: BigInteger
          val _tmp_7: String?
          if (_stmt.isNull(_columnIndexOfTokenId)) {
            _tmp_7 = null
          } else {
            _tmp_7 = _stmt.getText(_columnIndexOfTokenId)
          }
          val _tmp_8: BigInteger? = __roomTypeConverters.bigIntegerFromString(_tmp_7)
          if (_tmp_8 == null) {
            error("Expected NON-NULL 'java.math.BigInteger', but it was NULL.")
          } else {
            _tmpTokenId = _tmp_8
          }
          val _tmpTokenName: String
          _tmpTokenName = _stmt.getText(_columnIndexOfTokenName)
          _tmpNft = Nft(_tmpType,_tmpContractAddress,_tmpTokenId,_tmpTokenName)
          _result = NftBalance(_tmpNft,_tmpBalance,_tmpSynced)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun setSynced(
    contractAddress: Address,
    tokenId: BigInteger,
    balance: Int,
  ) {
    val _sql: String =
        "UPDATE NftBalanceRecord SET synced = 1, balance = ? WHERE contractAddress = ? AND tokenId = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, balance.toLong())
        _argIndex = 2
        val _tmp: ByteArray? = __roomTypeConverters.addressToByteArray(contractAddress)
        if (_tmp == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindBlob(_argIndex, _tmp)
        }
        _argIndex = 3
        val _tmp_1: String? = __roomTypeConverters.bigIntegerToString(tokenId)
        if (_tmp_1 == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, _tmp_1)
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun setNotSynced(contractAddress: Address, tokenId: BigInteger) {
    val _sql: String =
        "UPDATE NftBalanceRecord SET synced = 0 WHERE contractAddress = ? AND tokenId = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: ByteArray? = __roomTypeConverters.addressToByteArray(contractAddress)
        if (_tmp == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindBlob(_argIndex, _tmp)
        }
        _argIndex = 2
        val _tmp_1: String? = __roomTypeConverters.bigIntegerToString(tokenId)
        if (_tmp_1 == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, _tmp_1)
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
