package io.horizontalsystems.nftkit.core.db

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class NftKitDatabase_Impl : NftKitDatabase() {
  private val _nftBalanceDao: Lazy<NftBalanceDao> = lazy {
    NftBalanceDao_Impl(this)
  }

  private val _eip721EventDao: Lazy<Eip721EventDao> = lazy {
    Eip721EventDao_Impl(this)
  }

  private val _eip1155EventDao: Lazy<Eip1155EventDao> = lazy {
    Eip1155EventDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(1,
        "7ec78ccffde3bd610e67e052ac16475f", "30dc339e0736ef89189d88c2bd6430c6") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `Eip721Event` (`hash` BLOB NOT NULL, `blockNumber` INTEGER NOT NULL, `contractAddress` BLOB NOT NULL, `from` BLOB NOT NULL, `to` BLOB NOT NULL, `tokenId` TEXT NOT NULL, `tokenName` TEXT NOT NULL, `tokenSymbol` TEXT NOT NULL, `tokenDecimal` INTEGER NOT NULL, `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `Eip1155Event` (`hash` BLOB NOT NULL, `blockNumber` INTEGER NOT NULL, `contractAddress` BLOB NOT NULL, `from` BLOB NOT NULL, `to` BLOB NOT NULL, `tokenId` TEXT NOT NULL, `tokenValue` INTEGER NOT NULL, `tokenName` TEXT NOT NULL, `tokenSymbol` TEXT NOT NULL, `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `NftBalanceRecord` (`type` TEXT NOT NULL, `contractAddress` BLOB NOT NULL, `tokenId` TEXT NOT NULL, `tokenName` TEXT NOT NULL, `balance` INTEGER NOT NULL, `synced` INTEGER NOT NULL, PRIMARY KEY(`contractAddress`, `tokenId`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '7ec78ccffde3bd610e67e052ac16475f')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `Eip721Event`")
        connection.execSQL("DROP TABLE IF EXISTS `Eip1155Event`")
        connection.execSQL("DROP TABLE IF EXISTS `NftBalanceRecord`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsEip721Event: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsEip721Event.put("hash", TableInfo.Column("hash", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("blockNumber", TableInfo.Column("blockNumber", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("contractAddress", TableInfo.Column("contractAddress", "BLOB", true,
            0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("from", TableInfo.Column("from", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("to", TableInfo.Column("to", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("tokenId", TableInfo.Column("tokenId", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("tokenName", TableInfo.Column("tokenName", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("tokenSymbol", TableInfo.Column("tokenSymbol", "TEXT", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("tokenDecimal", TableInfo.Column("tokenDecimal", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip721Event.put("id", TableInfo.Column("id", "INTEGER", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysEip721Event: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesEip721Event: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoEip721Event: TableInfo = TableInfo("Eip721Event", _columnsEip721Event,
            _foreignKeysEip721Event, _indicesEip721Event)
        val _existingEip721Event: TableInfo = read(connection, "Eip721Event")
        if (!_infoEip721Event.equals(_existingEip721Event)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |Eip721Event(io.horizontalsystems.nftkit.models.Eip721Event).
              | Expected:
              |""".trimMargin() + _infoEip721Event + """
              |
              | Found:
              |""".trimMargin() + _existingEip721Event)
        }
        val _columnsEip1155Event: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsEip1155Event.put("hash", TableInfo.Column("hash", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("blockNumber", TableInfo.Column("blockNumber", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("contractAddress", TableInfo.Column("contractAddress", "BLOB",
            true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("from", TableInfo.Column("from", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("to", TableInfo.Column("to", "BLOB", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("tokenId", TableInfo.Column("tokenId", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("tokenValue", TableInfo.Column("tokenValue", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("tokenName", TableInfo.Column("tokenName", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("tokenSymbol", TableInfo.Column("tokenSymbol", "TEXT", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEip1155Event.put("id", TableInfo.Column("id", "INTEGER", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysEip1155Event: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesEip1155Event: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoEip1155Event: TableInfo = TableInfo("Eip1155Event", _columnsEip1155Event,
            _foreignKeysEip1155Event, _indicesEip1155Event)
        val _existingEip1155Event: TableInfo = read(connection, "Eip1155Event")
        if (!_infoEip1155Event.equals(_existingEip1155Event)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |Eip1155Event(io.horizontalsystems.nftkit.models.Eip1155Event).
              | Expected:
              |""".trimMargin() + _infoEip1155Event + """
              |
              | Found:
              |""".trimMargin() + _existingEip1155Event)
        }
        val _columnsNftBalanceRecord: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsNftBalanceRecord.put("type", TableInfo.Column("type", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsNftBalanceRecord.put("contractAddress", TableInfo.Column("contractAddress", "BLOB",
            true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsNftBalanceRecord.put("tokenId", TableInfo.Column("tokenId", "TEXT", true, 2, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsNftBalanceRecord.put("tokenName", TableInfo.Column("tokenName", "TEXT", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsNftBalanceRecord.put("balance", TableInfo.Column("balance", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsNftBalanceRecord.put("synced", TableInfo.Column("synced", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysNftBalanceRecord: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesNftBalanceRecord: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoNftBalanceRecord: TableInfo = TableInfo("NftBalanceRecord",
            _columnsNftBalanceRecord, _foreignKeysNftBalanceRecord, _indicesNftBalanceRecord)
        val _existingNftBalanceRecord: TableInfo = read(connection, "NftBalanceRecord")
        if (!_infoNftBalanceRecord.equals(_existingNftBalanceRecord)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |NftBalanceRecord(io.horizontalsystems.nftkit.models.NftBalanceRecord).
              | Expected:
              |""".trimMargin() + _infoNftBalanceRecord + """
              |
              | Found:
              |""".trimMargin() + _existingNftBalanceRecord)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "Eip721Event", "Eip1155Event",
        "NftBalanceRecord")
  }

  public override fun clearAllTables() {
    super.performClear(false, "Eip721Event", "Eip1155Event", "NftBalanceRecord")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(NftBalanceDao::class, NftBalanceDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(Eip721EventDao::class, Eip721EventDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(Eip1155EventDao::class, Eip1155EventDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun nftBalanceDao(): NftBalanceDao = _nftBalanceDao.value

  public override fun eip721EventDao(): Eip721EventDao = _eip721EventDao.value

  public override fun eip1155EventDao(): Eip1155EventDao = _eip1155EventDao.value
}
